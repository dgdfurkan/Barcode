/**
 * Modül: Hızlı Bul (sipariş içi ürün arama)
 * ============================================================================
 *
 * warehouse.getir.com sipariş panelinde arama çubuğu açar. Kart içindeki
 * ürünleri arar, kategori renkleriyle boyar, sipariş içeriklerini yerel
 * önbellekte tutar.
 *
 * Kaynağı `getir_hizli_bulucu/content.js`. Gövde birebir kopyalandı.
 * Önceki turda yanlış eklenti (`getir-warehouse-orders-search-extension`)
 * taşınmıştı, o modül silindi.
 *
 * SAYFA KISITI
 * Yalnızca sipariş listesi sayfasında uyanıyor:
 *   /r/<depoKimligi>/dashboard/orders
 * Depo kimliği sabit değil, depodan depoya değişiyor; adresten okunuyor.
 *
 * GETİR'İ YORMUYOR
 * Kaynaktaki hız sınırları olduğu gibi korundu: sipariş detayları tek tek
 * ve aralarında 1,5 saniye beklemeyle çekiliyor, çekilen sipariş yerel
 * önbelleğe yazılıp bir daha istenmiyor. Paralel istek yok, yeniden deneme
 * döngüsü yok.
 *
 * JETON YAKALAMA
 * Eskiden `inject.js` sayfaya script etiketiyle enjekte ediliyordu. Artık
 * `sayfa-koprusu.js` manifest üzerinden sayfanın dünyasında çalışıyor;
 * `GETIR_TOKEN_CAPTURED` ve `GETIR_DATA_RECEIVED` mesajlarını o yayınlıyor.
 * Böylece `web_accessible_resources` gerekmiyor, eklentinin dosyaları
 * dışarıya hiç açılmıyor.
 * ============================================================================
 */
(function (global) {
    'use strict';

    var JBA = global.JBA;
    if (!JBA) return;

    /*
     * Getir'in CSS sınıf adlarında karma var (orderCard--LDG_w gibi). Karma
     * her yayında değişebiliyor ve değiştiği gün eklenti sessizce ölürdü.
     * Seçiciler artık öneke bakıyor, karmaya değil.
     */

    /**
     * Yalnız sipariş listesi sayfası. Depo kimliği 24 haneli onaltılık ve
     * her depoda farklı, o yüzden desende sabit değil kalıp var.
     */
    var SIPARIS_YOLU = /^\/r\/[a-f0-9]{24}\/dashboard\/orders\/?$/;

    /*
     * Açık zemin. Koyu denendi ve kategori renkleri (mor, sarı) siyah üstünde
     * bozuluyordu; kullanıcının seçtiği renkler beyaz zeminde doğru okunuyor.
     * Palet: beyaz yüzey, kırık beyaz kağıt, mürekkep yazı, logo mavisi tek
     * vurgu. İki renk arası degrade yok, emoji yok, simgeler satır içi SVG.
     */
    var STIL = `#jba-hb {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 999999;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;

    /* Kurye adının üstüne denk gelip göz yorduğu için sönük duruyor.
       Fare yaklaşınca, içine odaklanınca ya da panel açıkken tam görünür. */
    opacity: 0.32;
    transition: opacity 0.18s ease;

    --yuzey: #ffffff;
    --kagit: #f7f6f2;
    --cizgi: #e7e5de;
    --cizgi-2: #f0eeE8;
    --yazi: #131720;
    --sonuk: #6b7280;
    --mavi: #135bec;
    --mavi-yumusak: #eef3ff;
}
#jba-hb:hover,
#jba-hb:focus-within,
#jba-hb.jba-hb--acik { opacity: 1; }

/* [hidden] tek başına yetmiyor: aşağıda display veren kurallar var ve
   belirlilik yarışını onlar kazanıyor. Bu satır olmazsa hiç kapanmaz. */
#jba-hb [hidden] { display: none !important; }

#jba-hb button { font-family: inherit; }
#jba-hb svg { display: block; flex: none; }

/* ---------------- AÇMA DÜĞMESİ ---------------- */
#jba-hb #jba-hb-fab {
    width: 48px;
    height: 48px;
    background: var(--yazi);
    color: #fff;
    border-radius: 14px;
    display: flex;
    justify-content: center;
    align-items: center;
    box-shadow: 0 6px 18px rgba(19,23,32,0.24);
    cursor: pointer;
    transition: transform 0.15s ease, background 0.15s ease;
}
#jba-hb #jba-hb-fab:hover { transform: translateY(-1px); background: var(--mavi); }

/* ---------------- PANEL ---------------- */
#jba-hb #jba-hb-panel {
    width: 372px;
    background: var(--yuzey);
    border: 1px solid var(--cizgi);
    border-radius: 16px;
    box-shadow: 0 18px 44px rgba(19,23,32,0.16);
    display: flex;
    flex-direction: column;
    max-height: 620px;
    color: var(--yazi);
    overflow: visible;
}

#jba-hb .panel-header {
    background: transparent;
    border-bottom: 1px solid var(--cizgi);
    padding: 13px 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 600;
    font-size: 14px;
    letter-spacing: -0.01em;
    flex-shrink: 0;
}
#jba-hb .panel-header > span { display: flex; align-items: center; gap: 8px; }
#jba-hb .header-buttons { display: flex; gap: 4px; }
#jba-hb .icon-btn {
    background: transparent;
    border: 0;
    color: var(--sonuk);
    cursor: pointer;
    width: 28px; height: 28px;
    display: flex; align-items: center; justify-content: center;
    border-radius: 8px;
    padding: 0;
}
#jba-hb .icon-btn:hover { background: var(--kagit); color: var(--yazi); }

#jba-hb .panel-body {
    padding: 12px 14px 14px;
    display: flex;
    flex-direction: column;
    gap: 10px;
}

#jba-hb .token-expiry-badge {
    font-size: 11px;
    font-weight: 500;
    color: var(--sonuk);
    display: flex;
    align-items: center;
    gap: 6px;
}
#jba-hb .token-expiry-badge::before {
    content: '';
    width: 6px; height: 6px;
    border-radius: 50%;
    background: #16a34a;
    flex: none;
}
#jba-hb .auto-token-note { display: none; }

#jba-hb .arama-kutu { position: relative; }
#jba-hb .arama-kutu svg {
    position: absolute;
    left: 11px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--sonuk);
}
#jba-hb .search-input {
    padding-left: 34px !important;
    font-size: 13px !important;
}

/* ---------------- SONUÇLAR ---------------- */
#jba-hb .search-results {
    background: var(--kagit);
    border: 1px solid var(--cizgi);
    border-radius: 10px;
    overflow: hidden auto;
    max-height: 260px;
    font-size: 12px;
}
#jba-hb .sr-header {
    padding: 7px 11px;
    font-weight: 600;
    font-size: 11px;
    color: var(--sonuk);
    border-bottom: 1px solid var(--cizgi);
    position: sticky;
    top: 0;
    background: var(--kagit);
}
#jba-hb .sr-empty { padding: 14px 11px; color: var(--sonuk); text-align: center; }
#jba-hb .sr-row {
    display: flex;
    flex-direction: column;
    gap: 3px;
    padding: 9px 11px;
    min-height: 44px;
    border-bottom: 1px solid var(--cizgi-2);
    cursor: pointer;
    background: var(--yuzey);
    transition: background 0.12s ease;
}
#jba-hb .sr-row:hover { background: var(--mavi-yumusak); }
#jba-hb .sr-row:last-child { border-bottom: none; }
#jba-hb .sr-ust { display: flex; align-items: center; gap: 8px; }
#jba-hb .sr-ust .sr-courier { margin-left: auto; }
#jba-hb .sr-alt { display: flex; justify-content: space-between; align-items: center; gap: 8px; font-size: 11px; color: var(--sonuk); }
#jba-hb .sr-bnk {
    font-weight: 700;
    font-size: 12px;
    color: var(--yazi);
    letter-spacing: 0.02em;
}
#jba-hb .sr-courier,
#jba-hb .sr-bnk,
#jba-hb .sr-count {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    max-width: 170px;
}
#jba-hb .sr-courier { font-size: 11px; color: var(--sonuk); }
#jba-hb .sr-adet { color: var(--mavi); font-weight: 600; }

/* Kategori renkleri kullanıcının seçtiği renkler; beyaz zeminde nokta
   olarak doğru okunuyor. */
#jba-hb .sr-noktalar { display: flex; gap: 3px; flex: none; }
#jba-hb .sr-noktalar i {
    width: 7px; height: 7px;
    border-radius: 50%;
    display: block;
    box-shadow: 0 0 0 1px rgba(19,23,32,0.12) inset;
}

#jba-hb .jba-hb-kuyruk-text {
    font-size: 10.5px;
    color: var(--sonuk);
    text-align: right;
}

/* ---------------- ORTAK KONTROLLER ---------------- */
#jba-hb .custom-input {
    width: 100%;
    padding: 9px 10px;
    background: var(--yuzey);
    border: 1px solid var(--cizgi);
    border-radius: 10px;
    color: var(--yazi);
    font-size: 13px;
    box-sizing: border-box;
    font-family: inherit;
}
#jba-hb .custom-input::placeholder { color: #9aa1ad; }
#jba-hb .custom-input:focus {
    outline: none;
    border-color: var(--mavi);
    box-shadow: 0 0 0 3px rgba(19,91,236,0.14);
}
#jba-hb textarea.custom-input { resize: vertical; min-height: 54px; }

#jba-hb .btn-primary {
    background: var(--mavi);
    color: #fff;
    border: none;
    padding: 10px;
    font-weight: 600;
    font-size: 13px;
    border-radius: 10px;
    cursor: pointer;
    width: 100%;
    min-height: 38px;
}
#jba-hb .btn-primary:hover { background: #0f4bc4; }
#jba-hb .btn-danger {
    background: #fff;
    color: #dc2626;
    border: 1px solid #f3c9c9;
    padding: 8px;
    font-weight: 600;
    font-size: 12px;
    border-radius: 10px;
    cursor: pointer;
    min-height: 38px;
}
#jba-hb .btn-danger:hover { background: #fdf1f1; }
#jba-hb .btn-vazgec {
    background: #fff;
    border: 1px solid var(--cizgi);
    border-radius: 10px;
    color: var(--sonuk);
    font: 600 12px inherit;
    cursor: pointer;
    min-height: 38px;
}
#jba-hb .btn-vazgec:hover { background: var(--kagit); color: var(--yazi); }
#jba-hb .btn-secondary-sm {
    width: 100%;
    background: #fff;
    border: 1px solid var(--cizgi);
    border-radius: 10px;
    padding: 9px 10px;
    font-size: 12px;
    cursor: pointer;
    color: var(--sonuk);
    display: flex;
    align-items: center;
    gap: 7px;
    min-height: 38px;
}
#jba-hb .btn-secondary-sm:hover { background: var(--kagit); color: var(--yazi); }

/* ---------------- AYARLAR ---------------- */
#jba-hb .settings-body {
    display: none;
    flex-direction: column;
    max-height: 560px;
}
#jba-hb .settings-form {
    padding: 12px 14px;
    border-bottom: 1px solid var(--cizgi);
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
}
#jba-hb .ekle-btn {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
    background: #fff;
    border: 1px dashed #d5d2c8;
    border-radius: 10px;
    color: var(--sonuk);
    font: 600 12px inherit;
    padding: 10px;
    cursor: pointer;
}
#jba-hb .ekle-btn:hover { border-color: var(--mavi); color: var(--mavi); }
#jba-hb #jba-hb-form-govde { display: flex; flex-direction: column; gap: 10px; margin-top: 10px; }

#jba-hb .ayar-baslik { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; }
#jba-hb .ayar-baslik h4 { margin: 0; font-size: 13px; font-weight: 600; color: var(--yazi); }
#jba-hb .ayar-baslik span { font-size: 10.5px; color: var(--sonuk); }
#jba-hb .alan { display: flex; flex-direction: column; gap: 4px; }
#jba-hb .alan > label {
    font-size: 10px;
    font-weight: 600;
    color: var(--sonuk);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
#jba-hb .alan > small { font-size: 10.5px; color: #9aa1ad; }
#jba-hb .renk-satiri {
    display: flex;
    align-items: center;
    gap: 8px;
    background: var(--kagit);
    border: 1px solid var(--cizgi);
    border-radius: 10px;
    padding: 8px 10px;
}
#jba-hb .renk-satiri label { flex: 1; font-size: 11.5px; font-weight: 600; color: var(--sonuk); }
#jba-hb .renk-satiri input[type="color"] {
    border: none;
    background: none;
    width: 36px;
    height: 26px;
    padding: 0;
    cursor: pointer;
    border-radius: 6px;
    overflow: hidden;
}
#jba-hb .form-dugmeler { display: grid; grid-template-columns: 1fr; gap: 8px; }
#jba-hb .form-dugmeler.duzenleme { grid-template-columns: 1fr 92px; }

#jba-hb #jba-hb-kat-liste {
    padding: 12px 14px;
    overflow-y: auto;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
    gap: 8px;
    background: var(--kagit);
}
#jba-hb .kat-bos {
    text-align: center;
    color: var(--sonuk);
    font-size: 12px;
    line-height: 1.6;
    padding: 22px 12px;
    background: #fff;
    border: 1px dashed #d5d2c8;
    border-radius: 10px;
}
#jba-hb .category-card {
    background: #fff;
    border: 1px solid var(--cizgi);
    border-left: 3px solid;
    padding: 11px 12px;
    border-radius: 10px;
}
#jba-hb .kat-ust { display: flex; justify-content: space-between; align-items: center; gap: 6px; }
#jba-hb .kat-ad {
    font-size: 12.5px;
    font-weight: 600;
    color: var(--yazi);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
#jba-hb .kat-rozetler { margin-top: 8px; display: flex; flex-wrap: wrap; gap: 4px; }
#jba-hb .action-btn {
    background: transparent;
    border: none;
    cursor: pointer;
    color: var(--sonuk);
    width: 26px; height: 26px;
    display: inline-flex; align-items: center; justify-content: center;
    border-radius: 7px;
    padding: 0;
}
#jba-hb .action-btn:hover { background: var(--kagit); color: var(--yazi); }
#jba-hb .action-btn.sil-btn:hover { color: #dc2626; background: #fdf1f1; }

#jba-hb .badge {
    padding: 3px 8px;
    border-radius: 7px;
    font-size: 10.5px;
    font-weight: 500;
    display: inline-block;
    border: 1px solid;
}
#jba-hb .badge.inc { color: #15803d; border-color: #bbf0cc; background: #f0fdf4; }
#jba-hb .badge.exc { color: #b91c1c; border-color: #f3c9c9; background: #fef2f2; }
#jba-hb .badge::before { font-weight: 700; margin-right: 4px; opacity: 0.65; }
#jba-hb .badge.inc::before { content: '+'; }
#jba-hb .badge.exc::before { content: '-'; }

/* ---------------- GELİŞMİŞ ---------------- */
#jba-hb .advanced-section {
    padding: 12px 14px;
    border-top: 1px solid var(--cizgi);
    flex-shrink: 0;
}
#jba-hb .advanced-note {
    font-size: 11px;
    color: #92610a;
    margin: 0 0 8px 0;
    background: #fffbeb;
    border: 1px solid #fce8b2;
    padding: 7px 9px;
    border-radius: 8px;
    line-height: 1.45;
}

/* Kart üstüne konan parça sayısı rozeti (panelin dışında, Getir'in kartında) */
.g-count-badge {
    display: inline-block !important;
    background: #131720 !important;
    color: #fff !important;
    font-size: 10px !important;
    font-weight: 700 !important;
    padding: 1px 6px !important;
    border-radius: 6px !important;
    margin-right: 6px !important;
    line-height: 1.4 !important;
    letter-spacing: 0.02em !important;
    width: auto !important;
    max-width: max-content !important;
    flex: none !important;
    align-self: flex-start !important;
    vertical-align: middle !important;
    white-space: nowrap !important;
}
.g-count-badge--yuzen {
    position: absolute !important;
    top: 4px !important;
    right: 4px !important;
    left: auto !important;
    bottom: auto !important;
    margin: 0 !important;
    z-index: 10 !important;
    box-shadow: 0 1px 3px rgba(0,0,0,0.18) !important;
}`;

    function stilKur() {
        if (document.getElementById('jba-hizli-bul-stil')) return;
        var s = document.createElement('style');
        s.id = 'jba-hizli-bul-stil';
        s.textContent = STIL;
        (document.head || document.documentElement).appendChild(s);
    }

    /* Emoji yerine satır içi SVG. Emoji her işletim sisteminde başka
       görünüyor ve panelin dilini bozuyordu. */
    var SVG = {
        ara: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>',
        araBuyuk: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>',
        ayar: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h8M17 6h3M4 12h3M12 12h8M4 18h8M17 18h3"/><circle cx="14.5" cy="6" r="2"/><circle cx="9.5" cy="12" r="2"/><circle cx="14.5" cy="18" r="2"/></svg>',
        kapat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
        kalem: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>',
        cop: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>',
        kilit: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="4" y="10" width="16" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>'
    };

    var kuruldu = false;

    function calistir() {
        if (kuruldu) return;
        kuruldu = true;
        stilKur();


        // Jeton ve API yanıtı yakalama artık `sayfa-koprusu.js` içinde
        // (manifest'te world: MAIN). Buraya betik enjekte etmeye ve
        // web_accessible_resources'a gerek kalmadı.

        // === STATE ===
        /* Cache şeması sürüm etiketi. Eklenti güncellenip yeni alanlar
           (ör. toplayiciFoto, kuryeFoto) eklendiğinde eski localStorage
           cache'i geçersiz sayılıyor ki tekrar fetch olsun ve DB doğru
           dolsun. Yeni alan eklediğinde bu numarayı artır. */
        const CACHE_SURUMU = 3;
        let orderCache = {};
        try {
            const kaydedilen = JSON.parse(localStorage.getItem('getir_order_cache')) || {};
            if (kaydedilen && kaydedilen.__v === CACHE_SURUMU) {
                orderCache = kaydedilen;
                delete orderCache.__v;
            } else {
                try { localStorage.removeItem('getir_order_cache'); } catch (e) {}
            }
        } catch (e) {}

        let idMap = {};
        let fetchQueue = [];
        let fetchQueueSet = new Set(); // O(1) lookup — performans iyileştirmesi
        let isFetching = false;
        let isRadarActive = false;
        let isSettingsOpen = false;
        let editingCategoryIndex = -1;

        const DEFAULT_CATEGORIES = [
            {
                name: 'Su',
                includes: ['erikli doğal kaynak suyu', 'hayat su', 'kuzeyden doğal mineralli su', 'damla su'],
                excludes: ['kuzeyden cam', 'erikli cam'],
                color: '#0088ff'
            },
            {
                name: 'Fırın',
                includes: ['ekmek', 'la lorraine'],
                excludes: ['uno', 'untad'],
                color: '#ffff00'
            },
            {
                name: 'Dondurma',
                includes: ['cornetto', 'golf', 'buz küpü', 'algida', 'carte', 'feast', 'superfresh', 'donuk', 'dondurulmuş', 'magnum', 'eti alaska frigo', 'pela', 'dondurmalı', 'mochiko', 'mars snickers', 'bauvian', 'panda', 'dondurma', 'porsi10'],
                excludes: [],
                color: '#bb00ff'
            }
        ];

        let userSettings = [];
        try {
            const saved = localStorage.getItem('getir_settings');
            userSettings = saved ? (JSON.parse(saved) || []) : DEFAULT_CATEGORIES;
            // İlk kez yükleniyorsa default'ları kaydet
            if (!saved) localStorage.setItem('getir_settings', JSON.stringify(DEFAULT_CATEGORIES));
        } catch (e) { userSettings = DEFAULT_CATEGORIES; }

        let userToken = localStorage.getItem('getir_manual_token') || '';
        let warehouseId = '';
        const urlMatch = window.location.href.match(/\/r\/([a-f0-9]+)\//);
        if (urlMatch) warehouseId = urlMatch[1];

        // === HELPERS ===
        const saveCache = () => {
            try {
                const paket = Object.assign({ __v: CACHE_SURUMU }, orderCache);
                localStorage.setItem('getir_order_cache', JSON.stringify(paket));
            } catch (e) {}
        };

        /* Konsol yardımcıları. warehouse.getir.com sekmesinde F12 → Console:
           - jbaLog()   son 30 yazma denemesini tabloda gösterir
           - jbaCache() orderCache içeriğini döner
           - jbaTemizle() logu ve cache'i siler, taze başlar */
        try {
            window.jbaLog = function () {
                var l = [];
                try { l = JSON.parse(localStorage.getItem('jba_yazma_log') || '[]'); } catch (e) {}
                console.table(l);
                return l;
            };
            window.jbaCache = function () { return orderCache; };
            window.jbaTemizle = function () {
                try { localStorage.removeItem('jba_yazma_log'); } catch (e) {}
                try { localStorage.removeItem('getir_order_cache'); } catch (e) {}
                console.log('[JBA] log ve cache silindi, sayfayı yenile.');
            };
        } catch (e) {}

        const getTokenExpiry = (token) => {
            if (!token) return 'Oturum anahtarı yok';
            try {
                const raw = token.replace(/^Bearer\s+/i, '');
                const payload = JSON.parse(atob(raw.split('.')[1]));
                const timeLeft = Math.floor((payload.exp * 1000 - Date.now()) / 60000);
                if (timeLeft <= 0) return 'Oturum süresi doldu';
                return `Oturum ${timeLeft} dk geçerli`;
            } catch (e) { return 'Oturum aktif'; }
        };

        const findOrderIds = (obj) => {
            if (!obj || typeof obj !== 'object') return;
            if (Array.isArray(obj)) { obj.forEach(findOrderIds); return; }
            if (obj.id && typeof obj.id === 'string' && obj.id.length === 24) {
                idMap[obj.id.slice(-4)] = obj.id;
            }
            Object.values(obj).forEach(findOrderIds);
        };

        // Hex → rgba dönüşümü (soft boyama için)
        const hexToRgba = (hex, alpha) => {
            const r = parseInt(hex.slice(1, 3), 16);
            const g = parseInt(hex.slice(3, 5), 16);
            const b = parseInt(hex.slice(5, 7), 16);
            return `rgba(${r},${g},${b},${alpha})`;
        };

        // Cache backward compatibility (eski format: array, yeni: {products, count})
        const getProducts = (entry) => Array.isArray(entry) ? entry : (entry?.products || []);
        const getCount = (entry) => Array.isArray(entry) ? null : (entry?.count ?? null);

        // Kelime bazlı eşleşme: İ/i, I/ı ve diğer Türkçe karakterler dahil tam harf duyarsız arama
        const normalizeStr = (str) => {
            if (!str) return '';
            return str.toLocaleLowerCase('tr-TR')
                .replace(/ı/g, 'i')
                .replace(/ğ/g, 'g')
                .replace(/ü/g, 'u')
                .replace(/ş/g, 's')
                .replace(/ö/g, 'o')
                .replace(/ç/g, 'c')
                .replace(/i̇/g, 'i');
        };

        const wordsMatch = (targetText, keyword) => {
            if (!targetText || !keyword) return false;
            const normTarget = normalizeStr(targetText);
            return normalizeStr(keyword).split(/\s+/).filter(Boolean).every(w => normTarget.includes(w));
        };

        // Sipariş kodu: barcode ikonlu ilk span
        const getShortCode = (card) => {
            const firstSpan = card.querySelector('[class*="textWithIcons--"] span.ant-typography');
            if (firstSpan) {
                const t = firstSpan.innerText?.trim();
                if (t && t.length === 4) return t;
            }
            // Fallback
            const span = Array.from(card.querySelectorAll('span')).find(s => {
                const t = s.innerText?.trim();
                return t && t.length === 4 && /^[a-f0-9]+$/i.test(t);
            });
            return span ? span.innerText.trim() : null;
        };

        // BNK kodu
        const getBnkCode = (card) => {
            const tag = card.querySelector('[class*="locationContainer--"] .ant-tag');
            return tag ? tag.innerText?.trim() : null;
        };

        // Bearer prefix
        const bearer = (t) => t.startsWith('Bearer') ? t : `Bearer ${t}`;
        const API_HEADERS = () => ({
            'Authorization': bearer(userToken),
            'Accept': 'application/json',
            'Countrycode': 'TR',
            'Language': 'tr',
            'X-Requester-Client': 'warehouse-panel-frontend'
        });

        // === RADAR ===
        /* Panelin kendi `/orders` yanıtı AKTİF siparişlerin tam listesi.
           DOM'dan okunan kart listesi eksik kalabiliyor (panel henüz
           render etmemiş, kolon görünmüyor, sanal liste). Bu yüzden
           temizlik kararında radar listesi de hesaba katılıyor: panelde
           duran bir sipariş DOM'da yakalanmadı diye silinmesin. */
        let sonRadarIdler = null;
        let sonRadarZamani = 0;
        const RADAR_TAZE_MS = 90 * 1000;

        const forceRadarFetch = async () => {
            if (isRadarActive || !userToken || !warehouseId) return;
            isRadarActive = true;
            try {
                const url = `https://warehouse-panel-api-gateway.getirapi.com/warehouse/${warehouseId}/orders?domainType=1`;
                const res = await fetch(url, { headers: API_HEADERS() });
                if (res.ok) {
                    const j = await res.json();
                    findOrderIds(j);
                    const siparisler = (j && j.data && Array.isArray(j.data.orders)) ? j.data.orders : null;
                    if (siparisler) {
                        sonRadarIdler = siparisler
                            .map((o) => o && o.id)
                            .filter((id) => typeof id === 'string' && id);
                        sonRadarZamani = Date.now();
                    }
                    /* Debug dökümü kapalı: Getir konsolunu kirletmesin.
                       İhtiyaç olursa `jbaListe()` çağrısıyla son yanıt alınır. */
                    window.__jbaListeSon = j;
                    window.jbaListe = () => window.__jbaListeSon;
                }
            } catch (e) {}
            setTimeout(() => { isRadarActive = false; }, 5000);
        };

        // === ARAMA SONUÇLARI ===
        const renderSearchResults = (term, matches) => {
            const el = document.getElementById('jba-hb-sonuc');
            if (!el) return;
            if (!term) { el.style.display = 'none'; el.innerHTML = ''; return; }

            el.style.display = 'block';
            if (matches.length === 0) {
                el.innerHTML = `<div class="sr-empty">Eşleşen sipariş yok</div>`;
                return;
            }

            el.innerHTML = `<div class="sr-header">${matches.length} siparişte bulundu</div>` +
                matches.map((m, i) => `
                    <div class="sr-row" data-idx="${i}">
                        <div class="sr-ust">
                            <span class="sr-bnk">${m.bnk}</span>
                            <span class="sr-noktalar">${(m.colors || []).map((c) => `<i style="background:${c}"></i>`).join('')}</span>
                            <span class="sr-courier">${m.courier}</span>
                        </div>
                        <div class="sr-alt">
                            <span class="sr-adet">${m.count !== null ? m.count + ' parça' : 'parça bilinmiyor'}</span>
                            <span class="sr-count">${m.hitCount ? m.hitCount + ' ürün eşleşti' : ''}</span>
                        </div>
                    </div>`).join('');

            el.querySelectorAll('.sr-row').forEach(row => {
                row.addEventListener('click', () => {
                    const idx = row.getAttribute('data-idx');
                    const match = matches[idx];
                    if (match && match.card) {
                        match.card.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        match.card.click();
                    }
                });
            });
        };

        /* Arama kapsamı. Tek kutu hem ürün hem kurye hem banko içinde arayınca
           kurye adı yazan ürün sonucu, ürün adı yazan kurye sonucu görüyordu.
           Artık nerede aranacağı seçili. */
        /* Kapsam seçici kaldırıldı. Dört düğme hem yer kaplıyordu hem de
           kullanıcı her seferinde doğru olanı seçmek zorunda kalıyordu.
           Arama artık her zaman ürün adında, kurye adında ve bankoda birden
           yapılıyor. Eski `getir_hb_kapsam` ayarı okunmuyor. */

        // === UI GÜNCELLEME ===
        const applyUI = () => {
            const term = document.getElementById('jba-hb-girdi')?.value?.trim?.() || '';
            const cards = document.querySelectorAll('[class*="orderCard--"]');
            const matches = [];

            cards.forEach(card => {
                const code = getShortCode(card);
                if (!code) return;

                const entry = orderCache[code];
                const products = getProducts(entry);
                const count = getCount(entry);
                let colors = [];
                let isMatch = false;
                let hitCount = 0;

                if (products.length > 0) {
                    userSettings.forEach(cat => {
                        const hit = products.some(p =>
                            (cat.includes || []).some(inc => wordsMatch(p, inc)) &&
                            !(cat.excludes || []).some(exc => wordsMatch(p, exc))
                        );
                        if (hit) colors.push(cat.color);
                    });
                    if (term) {
                        hitCount = products.filter(p => wordsMatch(p, term)).length;
                        if (hitCount > 0) isMatch = true;
                    }
                }

                // Kurye, müşteri ve BNK isimlerinde ara
                const nameElements = Array.from(card.querySelectorAll('[class*="textWithIcons--"] span.ant-typography'));
                const nameTexts = nameElements.map(s => s.innerText?.trim() || '');
                const bnk = getBnkCode(card) || 'BNK.?';
            
                if (term) {
                    if (nameTexts.some(t => wordsMatch(t, term))) isMatch = true;
                    if (wordsMatch(bnk, term)) isMatch = true;
                }

                // --- Soft arka plan boyama hesaplaması ---
                let newBg = '';
                if (colors.length === 1) {
                    newBg = hexToRgba(colors[0], 0.10);
                } else if (colors.length > 1) {
                    const stops = colors.flatMap((c, i) => {
                        const p1 = Math.round((i / colors.length) * 100);
                        const p2 = Math.round(((i + 1) / colors.length) * 100);
                        return [`${hexToRgba(c, 0.12)} ${p1}%`, `${hexToRgba(c, 0.12)} ${p2}%`];
                    });
                    newBg = `linear-gradient(to right, ${stops.join(', ')})`;
                }

                // Eşleşenleri listeye ekle
                if (term && isMatch) {
                    const courier = nameTexts.length >= 3 ? nameTexts[2] : 'Bilinmiyor';
                    matches.push({ card, bnk, courier, hitCount, count, bgColor: newBg, colors });
                }

                if (card.dataset.gBg !== newBg) {
                    card.style.background = newBg;
                    card.dataset.gBg = newBg;
                }

                // --- Parça sayısı badge ---
                // BNK etiketi varsa locationContainer'ın başına, yoksa
                // kartın sağ üstüne yüzen olarak. Sadece BNK etiketi (ant-tag)
                // varken container'ı hedefliyoruz; boş locationContainer'a
                // yerleştirmek kartın üstünü kaplayabiliyor.
                if (count !== null) {
                    const locationDiv = card.querySelector('[class*="locationContainer--"]');
                    const bnkTag = locationDiv && locationDiv.querySelector('.ant-tag');
                    const hedef = bnkTag ? locationDiv : card;
                    const yuzenOlmali = !bnkTag;
                    const txt = `×${count}`;
                    let badge = card.querySelector('.g-count-badge');
                    if (badge && badge.parentElement !== hedef) { badge.remove(); badge = null; }
                    if (!badge) {
                        badge = document.createElement('span');
                        badge.className = 'g-count-badge' + (yuzenOlmali ? ' g-count-badge--yuzen' : '');
                        if (yuzenOlmali) {
                            if (getComputedStyle(card).position === 'static') card.style.position = 'relative';
                            card.appendChild(badge);
                        } else {
                            hedef.insertBefore(badge, hedef.firstChild);
                        }
                    } else {
                        const yuzenSuAn = badge.classList.contains('g-count-badge--yuzen');
                        if (yuzenOlmali !== yuzenSuAn) badge.classList.toggle('g-count-badge--yuzen', yuzenOlmali);
                    }
                    if (badge.innerText !== txt) badge.innerText = txt;
                }

                // --- Arama opacity ---
                const newOp = term ? (isMatch ? '1' : '0.18') : '1';
                if (card.dataset.gOpacity !== newOp) {
                    card.style.opacity = newOp;
                    card.dataset.gOpacity = newOp;
                }
            });

            renderSearchResults(term, matches);
        };

        // === SYNC ===
        const updateQueueStatus = () => {
            const el = document.getElementById('jba-hb-kuyruk');
            if (el) el.innerText = `Kuyruk: ${fetchQueue.length} | Hafıza: ${Object.keys(orderCache).length} sipariş`;
        };

        const checkAndSync = () => {
            const cards = document.querySelectorAll('[class*="orderCard--"]');
            if (cards.length === 0) return;
            const visible = new Set();
            let needsRadar = false;

            cards.forEach(card => {
                const code = getShortCode(card);
                if (!code) return;
                visible.add(code);
                const longId = idMap[code];
                if (!longId) { needsRadar = true; return; }
                /* Görülen HER karta gonderilecek.add: cache olsun olmasın.
                   Cache doluysa fetch atlanır, ama JB_SIPARISLER handler'ı
                   siparişi yeniden yazma denemesi yapar. Böylece background
                   sendMessage'ı yuttuysa (service worker uyudu) bir sonraki
                   turda yeniden denenir. */
                gonderilecek.add(longId);
                if (!orderCache[code]) {
                    if (!fetchQueueSet.has(longId)) {
                        fetchQueue.push(longId);
                        fetchQueueSet.add(longId);
                        if (!isFetching) processQueue();
                    }
                }
            });

            let deleted = false;
            Object.keys(orderCache).forEach(k => { if (!visible.has(k)) { delete orderCache[k]; deleted = true; } });
            if (deleted) saveCache();
            if (needsRadar) forceRadarFetch();
            updateQueueStatus();
        };

        /**
         * Detay yanıtının ALAN ADLARINI bir kez yerel depoya yazar. Değer
         * değil, yalnız ad. Ürün kimliği ve görsel alanının adı belgelenmiş
         * değil; tahmin edip yanlış alan okumaktansa gerçek yanıttan
         * öğreniyoruz. Kayıt bir kez yazılıyor.
         *
         * Sayfa köprüsündeki `JB_SIPARIS_GETIR` yolu bu iş için kullanılamadı:
         * o yol sayfanın attığı bir `/orders` isteğini şablon alıyor, panel
         * ise sipariş listesini soketten aldığı için öyle bir istek hiç
         * geçmiyor ve çağrı "Failed to fetch" ile düşüyor. Buradaki kuyruk
         * yakalanan jetonla çalışıyor ve sorunsuz dönüyor.
         */
        const semayiKaydet = (siparis) => {
            try {
                if (!siparis || localStorage.getItem('jba_detay_sema')) return;
                const p0 = (Array.isArray(siparis.products) && siparis.products[0]) || null;
                const altlar = {};
                if (p0) {
                    Object.keys(p0).forEach((k) => {
                        const v = p0[k];
                        if (v && typeof v === 'object' && !Array.isArray(v)) altlar[k] = Object.keys(v);
                    });
                }
                localStorage.setItem('jba_detay_sema', JSON.stringify({
                    siparisAlanlari: Object.keys(siparis),
                    urunAlanlari: p0 ? Object.keys(p0) : null,
                    urunAltNesneler: altlar,
                    urunSatiri: Array.isArray(siparis.products) ? siparis.products.length : 0,
                    zaman: new Date().toISOString()
                }));
            } catch (e) { /* sessiz */ }
        };

        /* Detay çekimi başarısız olduğunda sessizce pes etmiyoruz. Geçici
           bir ağ hatası ya da 5xx yüzünden o siparişin ürünleri hiç
           yazılmıyordu ve kullanıcı "ürünler henüz gelmedi" ekranında
           kalıyordu. Üç deneme hakkı var; sonuncusu da tutmazsa panelde
           duran sipariş bir sonraki tarama turunda yeniden kuyruğa
           giriyor, yani kalıcı kayıp yok. */
        const denemeler = new Map();
        const MAX_DENEME = 3;

        const yenidenDene = (oId, sebep) => {
            const sayi = (denemeler.get(oId) || 0) + 1;
            denemeler.set(oId, sayi);
            const tekrar = sayi < MAX_DENEME;
            if (tekrar && !fetchQueueSet.has(oId)) {
                fetchQueue.push(oId);
                fetchQueueSet.add(oId);
            }
            try {
                let lg = JSON.parse(localStorage.getItem('jba_yazma_log') || '[]');
                lg.push({
                    id: oId.slice(-4),
                    sonuc: sebep + (tekrar ? ' · yeniden (' + sayi + '/' + MAX_DENEME + ')' : ' · vazgeçildi'),
                    saat: new Date().toLocaleTimeString('tr-TR')
                });
                if (lg.length > 60) lg = lg.slice(-60);
                localStorage.setItem('jba_yazma_log', JSON.stringify(lg));
            } catch (e) {}
        };

        /* ÜRÜNSÜZ YANIT
           Panel bazen 200 döndürüp ürün listesi vermiyor; çoğunlukla
           sipariş henüz Toplayıcı Bekliyor'dayken oluyor.

           Eski kod bu durumu hiç ele almıyordu. `products` yoksa
           `if (order?.products && ...)` bloğu atlanıyor, sipariş ne
           önbelleğe yazılıyor, ne yeniden deneniyor, ne log'a düşüyordu:
           sessizce kayboluyordu. "Ürünler henüz gelmedi" ekranının
           kaynağı buydu.

           `products` boş DİZİ geldiğinde ise daha kötüsü oluyordu.
           Önbellek boş ürünle yazılıyor, `siparisiYolla` "ürün yok" deyip
           önbelleği silip siparişi kuyruğun başına koyuyor, kuyruk yine
           boş ürün çekiyordu. Getir'e 700 ms'de bir vuran sonsuz döngü.

           Artık ürünsüz yanıt kendi soğuma süresini alıyor. Kişi
           fotoğrafları ise üründen bağımsız yazılıyor: ürün listesi
           gelmese de `picker`/`courier` yanıtta duruyor. */
        const urunsuzSoguma = new Map();
        const URUNSUZ_SOGUMA_MS = 60 * 1000;

        const sogumadaMi = (oId) => {
            const t = urunsuzSoguma.get(oId);
            return !!t && (Date.now() - t) < URUNSUZ_SOGUMA_MS;
        };

        /* Fotoğraf tek başına gönderilebilir. `siparisYaz` gövdeyi koşullu
           kuruyor: yalnız dolu alanlar gidiyor, boş alan DB'deki veriyi
           bozmuyor. Ürünsüz paket `satirlariYaz`'a hiç uğramıyor. */
        const kisiFotosunuYolla = (oId, toplayiciFoto, kuryeFoto) => {
            if (!toplayiciFoto && !kuryeFoto) return;
            const paket = { siparisId: oId, urunler: [] };
            if (toplayiciFoto) paket.toplayiciFoto = toplayiciFoto;
            if (kuryeFoto) paket.kuryeFoto = kuryeFoto;
            try {
                chrome.runtime.sendMessage(
                    { type: 'JBA_SIPARIS_YAZ', siparisler: [paket] },
                    () => { if (chrome.runtime.lastError) { /* SW uyuyor */ } }
                );
            } catch (e) { /* sessiz */ }
        };

        const birSiparisiCek = async (oId) => {
            const url = `https://warehouse-panel-api-gateway.getirapi.com/warehouse/${warehouseId}/orders/${oId}?domainType=1`;
            let res;
            try {
                res = await fetch(url, { headers: API_HEADERS() });
            } catch (e) {
                yenidenDene(oId, 'fetch err: ' + ((e && e.message) || 'x'));
                return;
            }

            /* Jeton eskimiş. Sipariş kuyrukta beklesin, deneme hakkı
               yanmasın: bu bizim değil, oturumun sorunu. Pompa da
               duraklıyor, yoksa çeyrek saniyede bir 401 yiyen bir döngü
               kurulurdu. */
            if (res.status === 401) {
                yetkiBeklemesi = Date.now();
                if (!fetchQueueSet.has(oId)) {
                    fetchQueue.unshift(oId);
                    fetchQueueSet.add(oId);
                }
                return;
            }
            if (!res.ok) { yenidenDene(oId, 'HTTP ' + res.status); return; }

            let order = null;
            try { order = (await res.json())?.data?.order; } catch (e) { /* bozuk gövde */ }
            if (!order) { yenidenDene(oId, 'govde yok'); return; }

            semayiKaydet(order);
            /* Debug dökümü kapalı: Getir konsolunu kirletmesin.
               İhtiyaç olursa `jbaDetay()` çağrısıyla son yanıt alınır. */
            window.__jbaDetaySon = order;
            window.jbaDetay = () => window.__jbaDetaySon;

            /* Kişi fotoğrafları detay yanıtından. Panel listesinde picURL
               çoğu zaman olmuyor; detay ise kesin veriyor. */
            const toplayiciFoto = (order.picker && order.picker.picURL) || '';
            const kuryeFoto = (order.courier && order.courier.picURL) || '';
            const urunler = Array.isArray(order.products) ? order.products : [];

            if (!urunler.length) {
                urunsuzSoguma.set(oId, Date.now());
                kisiFotosunuYolla(oId, toplayiciFoto, kuryeFoto);
                yenidenDene(oId, 'urun_yok');
                return;
            }

            urunsuzSoguma.delete(oId);
            orderCache[oId.slice(-4)] = {
                products: urunler.map(p => {
                    const n = p?.name?.tr || p?.name?.en || '';
                    return typeof n === 'string' ? n.toLowerCase() : '';
                }).filter(Boolean),
                count: order.basketProductCount ?? null,
                /* Toplayıcı Bekliyor ürünlerinde `index` boş olabiliyor;
                   öyleyse dizi konumu (1'den) sıra olur. */
                detay: urunler.map((p, i) => ({
                    sira: (p && p.index != null) ? p.index : (i + 1),
                    ad: (p?.name?.tr || p?.name?.en || '').trim(),
                    gorsel: (p?.picURL?.tr || p?.picURL?.en || '') || '',
                    adet: typeof p?.orderCount === 'number' ? p.orderCount : null
                })),
                toplayiciFoto: toplayiciFoto,
                kuryeFoto: kuryeFoto
            };
            saveCache();
            applyUI();
            denemeler.delete(oId);
            // Kullanıcı bu siparişi açtıysa artık gönderilebilir.
            if (gonderilecek.has(oId)) siparisiYolla(oId);
        };

        /* PARALEL KUYRUK
           Eskiden tek kanal vardı: bir sipariş çekilir, 700 ms beklenir,
           sıradakine geçilirdi. Yirmi siparişlik bir panelde sonuncunun
           ürünü ve kişi fotoğrafları on dört saniye sonra iniyordu.
           "Fotoğraflar geç geliyor" şikâyeti tam olarak bu kuyruktu.

           Üç kanal, kanal başına 250 ms. Aynı yirmi sipariş yaklaşık iki
           saniyede tamamlanıyor. Getir paneli kendi trafiğinde bundan
           fazlasını zaten atıyor.

           `isFetching` artık "en az bir kanal meşgul" demek. Dosyanın
           başka yerlerindeki `if (!isFetching) processQueue()` çağrıları
           olduğu gibi çalışıyor: kanal doluyken pompa zaten kendi
           kendini çağırıyor, iş kaybolmuyor. */
        const PARALEL_KANAL = 3;
        const CEKIM_ARALIK_MS = 250;
        const YETKI_BEKLEME_MS = 5000;
        let aktifCekim = 0;
        let yetkiBeklemesi = 0;

        const processQueue = () => {
            if (!userToken || !warehouseId) return;
            if (Date.now() - yetkiBeklemesi < YETKI_BEKLEME_MS) {
                setTimeout(processQueue, YETKI_BEKLEME_MS);
                return;
            }
            while (aktifCekim < PARALEL_KANAL && fetchQueue.length) {
                const oId = fetchQueue.shift();
                fetchQueueSet.delete(oId);
                /* Soğumadaki sipariş kuyruğu meşgul etmesin; panel onu
                   sonraki tarama turunda yeniden aday gösteriyor. */
                if (sogumadaMi(oId)) continue;
                aktifCekim++;
                isFetching = true;
                birSiparisiCek(oId).catch(() => {}).then(() => {
                    aktifCekim--;
                    isFetching = aktifCekim > 0;
                    updateQueueStatus();
                    if (fetchQueue.length) setTimeout(processQueue, CEKIM_ARALIK_MS);
                });
            }
            updateQueueStatus();
        };

        // === PANEL AÇ / KAPA ===
        const panelAcikMi = () => {
            const p = document.getElementById('jba-hb-panel');
            return !!p && p.style.display !== 'none';
        };

        const paneliAc = () => {
            const kap = document.getElementById('jba-hb');
            if (!kap) return;
            document.getElementById('jba-hb-fab').style.display = 'none';
            document.getElementById('jba-hb-panel').style.display = 'flex';
            kap.classList.add('jba-hb--acik');
            setTimeout(() => { document.getElementById('jba-hb-girdi')?.focus(); }, 50);
        };

        const paneliKapat = () => {
            const kap = document.getElementById('jba-hb');
            if (!kap) return;
            document.getElementById('jba-hb-panel').style.display = 'none';
            document.getElementById('jba-hb-fab').style.display = 'flex';
            kap.classList.remove('jba-hb--acik');
            isSettingsOpen = false;
            document.getElementById('jba-hb-ana').style.display = 'flex';
            document.getElementById('jba-hb-ayar').style.display = 'none';

            const g = document.getElementById('jba-hb-girdi');
            if (g) { g.value = ''; applyUI(); }
        };

        // === WIDGET ===
        const buildWidget = () => {
            if (document.getElementById('jba-hb')) return;
            const container = document.createElement('div');
            container.id = 'jba-hb';
            container.innerHTML = `
                <div id="jba-hb-fab" title="Hızlı Bul">${SVG.araBuyuk}</div>
                <div id="jba-hb-panel" style="display:none;">
                    <div class="panel-header">
                        <span>Hızlı Bul</span>
                        <div class="header-buttons">
                            <button id="jba-hb-ayar-btn" class="icon-btn" title="Ayarlar">${SVG.ayar}</button>
                            <button id="jba-hb-kapat" class="icon-btn" title="Kapat">${SVG.kapat}</button>
                        </div>
                    </div>

                    <div class="panel-body" id="jba-hb-ana">
                        <div id="jba-hb-jeton-durum" class="token-expiry-badge">${getTokenExpiry(userToken)}</div>
                        <div class="arama-kutu">
                            ${SVG.ara}
                            <input type="text" id="jba-hb-girdi" class="custom-input search-input" placeholder="Ürün, kurye ya da banko ara">
                        </div>
                        <div id="jba-hb-sonuc" class="search-results" style="display:none;"></div>
                        <div id="jba-hb-kuyruk" class="jba-hb-kuyruk-text">Kuyruk: 0 | Hafıza: 0 sipariş</div>
                    </div>

                    <div class="settings-body" id="jba-hb-ayar" style="display:none;">
                        <div class="settings-form">
                            <button type="button" class="ekle-btn" id="jba-hb-form-ac">
                                <span id="jba-hb-form-ac-yazi">Yeni kategori ekle</span>
                                <span class="isaret" id="jba-hb-form-ac-isaret">+</span>
                            </button>
                            <div id="jba-hb-form-govde" hidden>
                            <div class="ayar-baslik">
                                <h4>Kategori</h4>
                                <span>Kart arka planını boyar</span>
                            </div>
                            <div class="alan">
                                <label for="jba-hb-kat-ad">Başlık</label>
                                <input type="text" id="jba-hb-kat-ad" class="custom-input" placeholder="Örnek: Sular">
                            </div>
                            <div class="alan">
                                <label for="jba-hb-kat-dahil">Dahil edilecek kelimeler</label>
                                <textarea id="jba-hb-kat-dahil" class="custom-input" placeholder="erikli, hayat su" rows="2"></textarea>
                                <small>Virgülle ayır. Biri geçiyorsa kart boyanır.</small>
                            </div>
                            <div class="alan">
                                <label for="jba-hb-kat-haric">Hariç tutulacaklar</label>
                                <textarea id="jba-hb-kat-haric" class="custom-input" placeholder="cam, 1 lt" rows="2"></textarea>
                                <small>İsteğe bağlı. Bunlardan biri geçiyorsa boyanmaz.</small>
                            </div>
                            <div class="renk-satiri">
                                <label for="jba-hb-kat-renk">Kart rengi</label>
                                <input type="color" id="jba-hb-kat-renk" value="#0088ff">
                            </div>
                            <div class="form-dugmeler" id="jba-hb-form-dugmeler">
                                <button id="jba-hb-kat-kaydet" class="btn-primary">Kategoriyi Kaydet</button>
                                <button id="jba-hb-kat-vazgec" class="btn-vazgec" hidden>Vazgeç</button>
                            </div>
                            </div>
                        </div>
                        <div id="jba-hb-kat-liste"></div>
                        <div class="advanced-section">
                            <button id="jba-hb-gelismis" class="btn-secondary-sm">${SVG.kilit}<span>Gelişmiş ayarlar</span></button>
                            <div id="jba-hb-gelismis-icerik" style="display:none; padding:10px; border-top:1px solid #eee;">
                                <p class="advanced-note">Token otomatik alınmaktadır. Gerekmedikçe kullanmayın.</p>
                                <input type="text" id="jba-hb-jeton-girdi" class="custom-input" placeholder="Manuel Token" autocomplete="off" spellcheck="false" autocapitalize="off">
                                <div style="display:flex; gap:5px; margin-top:6px;">
                                    <button id="jba-hb-jeton-kaydet" class="btn-primary" style="flex:2">Kaydet</button>
                                    <button id="jba-hb-jeton-sifirla" class="btn-danger" style="flex:1">Sıfırla</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(container);

            document.getElementById('jba-hb-fab').onclick = paneliAc;
            document.getElementById('jba-hb-kapat').onclick = paneliKapat;
            document.getElementById('jba-hb-ayar-btn').onclick = () => {
                isSettingsOpen = !isSettingsOpen;
                document.getElementById('jba-hb-ana').style.display = isSettingsOpen ? 'none' : 'flex';
                document.getElementById('jba-hb-ayar').style.display = isSettingsOpen ? 'flex' : 'none';
                if (isSettingsOpen) renderCategories();
            };
            document.getElementById('jba-hb-gelismis').onclick = () => {
                const c = document.getElementById('jba-hb-gelismis-icerik');
                const open = c.style.display !== 'none';
                c.style.display = open ? 'none' : 'block';
                document.getElementById('jba-hb-gelismis').innerHTML =
                    SVG.kilit + '<span>' + (open ? 'Gelişmiş ayarlar' : 'Gizle') + '</span>';
            };
            document.getElementById('jba-hb-jeton-kaydet').onclick = () => {
                const val = document.getElementById('jba-hb-jeton-girdi').value;
                if (val) {
                    userToken = val.trim();
                    localStorage.setItem('getir_manual_token', userToken);
                    document.getElementById('jba-hb-jeton-durum').innerText = getTokenExpiry(userToken);
                    const btn = document.getElementById('jba-hb-jeton-kaydet');
                    btn.innerText = 'Kaydedildi';
                    setTimeout(() => { btn.innerText = 'Kaydet'; }, 2000);
                    if (!isFetching && fetchQueue.length > 0) processQueue();
                }
            };
            document.getElementById('jba-hb-jeton-sifirla').onclick = () => {
                if (confirm('Tüm hafıza silinsin mi?')) {
                    ['getir_order_cache', 'getir_settings', 'getir_manual_token'].forEach(k => localStorage.removeItem(k));
                    window.location.reload();
                }
            };
            document.getElementById('jba-hb-kat-kaydet').onclick = () => {
                const name = document.getElementById('jba-hb-kat-ad').value.trim();
                const inc = document.getElementById('jba-hb-kat-dahil').value.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
                const exc = document.getElementById('jba-hb-kat-haric').value.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
                const color = document.getElementById('jba-hb-kat-renk').value;
                if (name && inc.length > 0) {
                    const cat = { name, includes: inc, excludes: exc, color };
                    const idx = Number(editingCategoryIndex);
                    if (idx > -1) userSettings[idx] = cat;
                    else userSettings.push(cat);
                    localStorage.setItem('getir_settings', JSON.stringify(userSettings));
                    duzenlemeyiBitir();
                    renderCategories();
                    applyUI();
                }
            };
            document.getElementById('jba-hb-kat-vazgec').onclick = duzenlemeyiBitir;
            document.getElementById('jba-hb-form-ac').onclick = () => {
                const govde = document.getElementById('jba-hb-form-govde');
                const acilacak = govde.hidden;
                formuAc(acilacak);
                if (acilacak) document.getElementById('jba-hb-kat-ad').focus();
                else duzenlemeyiBitir();
            };
            /* Her tuşta sekiz kartı yeniden tarayıp yeniden çizmek yerine
               120 ms bekleniyor ve çizim tek kareye toplanıyor. */
            let aramaZaman = null;
            let cizimKare = 0;
            const aramaDegisti = () => {
                clearTimeout(aramaZaman);
                aramaZaman = setTimeout(() => {
                    /* Sekme arka plandayken requestAnimationFrame hiç
                       çalışmıyor; kuyruğa atılan çizim orada asılı kalıyordu.
                       Görünmezken doğrudan çiziliyor. */
                    if (document.visibilityState !== 'visible') { applyUI(); return; }
                    if (cizimKare) return;
                    cizimKare = requestAnimationFrame(() => { cizimKare = 0; applyUI(); });
                }, 120);
            };
            document.getElementById('jba-hb-girdi').oninput = aramaDegisti;
        };

        /* Kullanıcı metni HTML'e gömülüyor; kaçırılmazsa kendi ayar yazısı
           paneli bozabilir. */
        const kacir = (t) => String(t == null ? '' : t)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');

        const formuAc = (ac) => {
            const govde = document.getElementById('jba-hb-form-govde');
            const yazi = document.getElementById('jba-hb-form-ac-yazi');
            const isaret = document.getElementById('jba-hb-form-ac-isaret');
            if (!govde) return;
            govde.hidden = !ac;
            if (yazi) yazi.textContent = ac ? 'Formu kapat' : 'Yeni kategori ekle';
            if (isaret) isaret.textContent = ac ? '−' : '+';
        };

        const duzenlemeyiBitir = () => {
            editingCategoryIndex = -1;
            formuAc(false);
            const kaydet = document.getElementById('jba-hb-kat-kaydet');
            const vazgec = document.getElementById('jba-hb-kat-vazgec');
            const kap = document.getElementById('jba-hb-form-dugmeler');
            if (kaydet) kaydet.innerText = 'Kategoriyi Kaydet';
            if (vazgec) vazgec.hidden = true;
            if (kap) kap.classList.remove('duzenleme');
            ['jba-hb-kat-ad', 'jba-hb-kat-dahil', 'jba-hb-kat-haric'].forEach((id) => {
                const el = document.getElementById(id);
                if (el) el.value = '';
            });
        };

        const renderCategories = () => {
            const list = document.getElementById('jba-hb-kat-liste');
            if (!list) return;
            if (userSettings.length === 0) {
                list.innerHTML = `<div class="kat-bos">Henüz kategori yok.<br>Yukarıdan ekleyebilirsin.</div>`;
                return;
            }
            list.innerHTML = userSettings.map((cat, idx) => `
                <div class="category-card" style="border-left-color:${kacir(cat.color)};background:${hexToRgba(cat.color, 0.07)}">
                    <div class="kat-ust">
                        <span class="kat-ad">${kacir(cat.name)}</span>
                        <div style="display:flex;gap:2px;flex-shrink:0;">
                            <button class="action-btn edit-btn" data-idx="${idx}" title="Düzenle">${SVG.kalem}</button>
                            <button class="action-btn del-btn sil-btn" data-idx="${idx}" title="Sil">${SVG.cop}</button>
                        </div>
                    </div>
                    <div class="kat-rozetler">
                        ${cat.includes.map(k => `<span class="badge inc">${kacir(k)}</span>`).join('')}
                        ${(cat.excludes || []).map(k => `<span class="badge exc">${kacir(k)}</span>`).join('')}
                    </div>
                </div>
            `).join('');

            list.querySelectorAll('.del-btn').forEach(btn => {
                btn.onclick = (e) => {
                    userSettings.splice(Number(e.currentTarget.getAttribute('data-idx')), 1);
                    localStorage.setItem('getir_settings', JSON.stringify(userSettings));
                    renderCategories(); applyUI();
                };
            });
            list.querySelectorAll('.edit-btn').forEach(btn => {
                btn.onclick = (e) => {
                    const idx = Number(e.currentTarget.getAttribute('data-idx'));
                    const cat = userSettings[idx];
                    document.getElementById('jba-hb-kat-ad').value = cat.name;
                    document.getElementById('jba-hb-kat-dahil').value = cat.includes.join(', ');
                    document.getElementById('jba-hb-kat-haric').value = (cat.excludes || []).join(', ');
                    document.getElementById('jba-hb-kat-renk').value = cat.color;
                    editingCategoryIndex = idx;
                    formuAc(true);
                    document.getElementById('jba-hb-kat-kaydet').innerText = 'Güncelle';
                    document.getElementById('jba-hb-kat-vazgec').hidden = false;
                    document.getElementById('jba-hb-form-dugmeler').classList.add('duzenleme');
                    document.getElementById('jba-hb-ayar').scrollTop = 0;
                    document.getElementById('jba-hb-kat-ad').focus();
                };
            });
        };

        // ==================================================================
        // Jet Barkod'a aktarım
        //
        // Liste verisi (banko, adet, poşet, toplayıcı, kurye, kategori) sayfa
        // köprüsünden geliyor; ürün adı ve görseli detay kuyruğundan. İkisi
        // satır sırası (`index`) üzerinden birleşiyor.
        // ==================================================================

        let sonSiparisListesi = [];

        const birlestir = (s) => {
            const kod = String(s.siparisId || '').slice(-4);
            const girdi = orderCache[kod];
            const detay = (girdi && !Array.isArray(girdi) && girdi.detay) || [];
            const panelUrunler = Array.isArray(s.urunler) ? s.urunler : [];
            const panelHarita = new Map();
            panelUrunler.forEach((u) => panelHarita.set(u.sira, u));
            /* Toplayıcı Bekliyor / Doğrulanıyor gibi durumlarda panel React
               state'ine `products` dizisi henüz düşmemiş olabiliyor. Bu
               yüzden ürün ana kaynağı DETAY dizisi; kategori ve panelden
               gelen adet bilgisi varsa panelHarita'dan ekleniyor. Böylece
               panel `s.urunler` boş bile olsa DB'ye ürün satırları yazılır. */
            const kaynak = detay.length ? detay : panelUrunler;
            const urunler = kaynak.map((k) => {
                const p = panelHarita.get(k.sira) || {};
                const dSira = k.sira;
                return {
                    sira: dSira,
                    ad: k.ad || p.ad || '',
                    gorsel: k.gorsel || '',
                    /* Liste ile detay aynı adedi veriyor. Getir kilogramla
                       satılan üründe de bu alanı kullanıyor; çevirmiyoruz. */
                    adet: (typeof p.adet === 'number' ? p.adet : k.adet) || 1,
                    anaKategori: p.anaKategori || '',
                    sinif: p.sinif || '',
                    altSinif: p.altSinif || ''
                };
            });

            const sonuc = Object.assign({}, s, { urunler: urunler });
            /* Detay yanıtından foto varsa panel künyesindekini geçersin;
               panel listesinde çoğu zaman picURL boş kalıyor, detay
               kesin sonuç veriyor. */
            if (girdi && !Array.isArray(girdi)) {
                if (girdi.toplayiciFoto) sonuc.toplayiciFoto = girdi.toplayiciFoto;
                if (girdi.kuryeFoto) sonuc.kuryeFoto = girdi.kuryeFoto;
            }
            return sonuc;
        };

        /* Hangi siparişler gönderilmeyi bekliyor. Kullanıcı bir siparişe
           girdiğinde buraya giriyor, gönderildikten sonra çıkıyor. */
        const gonderilecek = new Set();

        /* Siparişin künyesi en son nasıl görüldü. Sipariş gövdesi bir kez
           yazılıyor (kullanıcı karta girdiğinde); sonrasında panelde banko
           atanıyor, toplayıcı değişiyor, kolon ilerliyor ve bizim kayıt
           eskiyordu. Burada yalnız DEĞİŞİM yakalanıyor; ilk görüş taban
           değer sayılıyor ve istek doğurmuyor. Getir'e ek istek çıkmıyor,
           veri zaten panelin kendi listesinde. */
        const sonKunye = new Map();

        const kunyeImzasi = (s) => [
            s.kolon, s.banko, s.durum, s.toplayici, s.kurye,
            s.toplayiciFoto, s.kuryeFoto, s.toplamAdet, s.posetSayisi
        ].join('~');

        const kisiImzasi = (s) => (s.toplayici || '') + '~' + (s.kurye || '');
        const sonKisi = new Map();

        const kunyeleriYolla = (liste, zorla) => {
            const degisen = [];
            const tumIdler = [];
            const yeniGelenler = [];
            liste.forEach((s) => {
                if (!s || !s.siparisId) return;
                tumIdler.push(s.siparisId);
                const yeni = kunyeImzasi(s);
                const eski = sonKunye.get(s.siparisId);
                sonKunye.set(s.siparisId, yeni);
                if (eski !== yeni) {
                    degisen.push(s);
                    /* Künye değişti: sipariş büyük ihtimalle sütun
                       atladı. Toplayıcı Bekliyor'da ürün vermeyen panel
                       Hazırlanıyor'da veriyor, o yüzden ürünsüz soğuma
                       burada kalkıyor ve sipariş yeniden aday oluyor.
                       Soğuma olmasaydı döngü, kalkmasaydı sipariş
                       sonsuza kadar ürünsüz kalırdı. */
                    if (urunsuzSoguma.has(s.siparisId)) {
                        urunsuzSoguma.delete(s.siparisId);
                        denemeler.delete(s.siparisId);
                        otoSorulan.delete(s.siparisId);
                        if (!fetchQueueSet.has(s.siparisId)) {
                            fetchQueue.push(s.siparisId);
                            fetchQueueSet.add(s.siparisId);
                        }
                    }
                }
                /* Bu sipariş ilk kez görülüyor. Detayı beklemeden, sıraya
                   girmeden çekilecek; kullanıcı "ürünler henüz gelmedi"
                   ekranını hiç görmemeli. */
                if (eski === undefined) yeniGelenler.push(s.siparisId);
                /* Kişi (toplayıcı/kurye) değiştiyse cache eskimiş demektir:
                   yeni kişinin fotoğrafını da almak için detayı yeniden çek. */
                const yeniKisi = kisiImzasi(s);
                const eskiKisi = sonKisi.get(s.siparisId);
                sonKisi.set(s.siparisId, yeniKisi);
                if (eskiKisi !== undefined && eskiKisi !== yeniKisi) {
                    const kod = s.siparisId.slice(-4);
                    if (orderCache[kod]) { delete orderCache[kod]; saveCache(); }
                    otoSorulan.delete(s.siparisId);
                }
            });
            /* YENİ SİPARİŞ ANINDA ÇEKİLİR
               Kuyruğun BAŞINA giriyor ve tur sınırına takılmıyor. Eskiden
               yeni sipariş sıranın sonuna ekleniyor, turda üç sipariş
               sınırı ve 1.5 saniyelik aralıkla birlikte yirmi siparişlik
               bir panelde otuz saniye bekliyordu. Kullanıcının gördüğü
               "ürünler henüz gelmedi" ekranı tam olarak o bekleme idi. */
            if (yeniGelenler.length) {
                yeniGelenler.forEach((id) => {
                    otoSorulan.add(id);
                    gonderilecek.add(id);
                    if (!fetchQueueSet.has(id)) {
                        fetchQueue.unshift(id);
                        fetchQueueSet.add(id);
                    }
                });
                if (!isFetching) processQueue();
            }

            /* KİMİN SÖZÜ GEÇER
               DOM'da kart varsa panel çizmiş demektir; o liste TAM listedir
               ve otoritedir. Teslim edilen sipariş DOM'dan düşer düşmez
               silinsin diye radarı işin içine karıştırmıyoruz.

               DOM boşsa iki ihtimal var: panel gerçekten boş, ya da React
               henüz çizmedi (sekmeye yeni dönüldü). Ayırt etmek için taze
               radar yanıtına bakıyoruz. Radar da bayatsa hiçbir şey
               yapmıyoruz: radarı tetikleyip susuyoruz, bir sonraki turda
               (2 sn) doğru kararı veriyoruz. Böylece "sekmeye döndüm, DB
               komple silindi" kazası imkânsız. */
            if (!tumIdler.length) {
                const radarTaze = sonRadarIdler && (Date.now() - sonRadarZamani < RADAR_TAZE_MS);
                if (!radarTaze) {
                    try { forceRadarFetch(); } catch (e) {}
                    return;
                }
                sonRadarIdler.forEach((id) => tumIdler.push(id));
            }

            /* Buraya geldiysek gönderiyoruz: künye değişmemiş olsa bile
               `tumIdler` arka planın temizlik girdisi. Göndermezsek panelden
               düşen sipariş DB'de kalır. sayfa-koprusu zaten imza aynıyken
               mesaj yollamıyor (20 sn'de bir heartbeat hariç), o yüzden bu
               yol seyrek işliyor ve fazladan trafik doğurmuyor. */
            const panelBos = tumIdler.length === 0;
            if (panelBos) sonKunye.clear();
            try {
                chrome.runtime.sendMessage(
                    { type: 'JBA_SIPARIS_KUNYE',
                      tumIdler: tumIdler,
                      panelBos: panelBos,
                      zorla: !!zorla,
                      siparisler: degisen.map((s) => ({
                        siparisId: s.siparisId,
                        kolon: s.kolon,
                        durum: s.durum,
                        banko: s.banko,
                        toplayici: s.toplayici,
                        kurye: s.kurye,
                        toplayiciFoto: s.toplayiciFoto,
                        kuryeFoto: s.kuryeFoto,
                        toplamAdet: s.toplamAdet,
                        posetSayisi: s.posetSayisi
                    })) },
                    () => { if (chrome.runtime.lastError) { /* hizmet işçisi uyuyor olabilir */ } }
                );
            } catch (e) { /* sessiz */ }
        };

        /* Hazırlık aşamasındaki (Toplayıcı Bekliyor, Doğrulanıyor,
           Hazırlanıyor) ya da bankosu atanmış siparişler otomatik alınıyor.
           Banko atanması güçlü bir sinyal: depocu o siparişle ilgileniyor.
           Hazırlık kolonuna düşen sipariş için de ürünleri getir ki
           Jet Barkod tarafında kart açık gelsin, "ürünler henüz gelmedi"
           beklemesin. Bir tur en fazla üç sipariş alıyor ki panel trafiği
           patlamasın; gerisi sonraki turda geliyor. */
        const otoSorulan = new Set();
        /* Tur başına alınacak sipariş sayısı. Yeni gelen siparişler bu
           yoldan değil, `kunyeleriYolla` içindeki öncelikli daldan
           gidiyor; buradaki sınır yalnız ilk açılışta panelde hâlihazırda
           duran yığını sindirmek için. 3 çok yavaştı, yirmi siparişlik
           panelde ilk tarama dakikaları buluyordu. */
        const OTO_TUR_SINIRI = 8;

        const _turkce = (t) => (t || '').toString().toLowerCase()
            .replace(/[ıİI]/g, 'i').replace(/[ğĞ]/g, 'g').replace(/[üÜ]/g, 'u')
            .replace(/[şŞ]/g, 's').replace(/[öÖ]/g, 'o').replace(/[çÇ]/g, 'c');
        const HAZIRLIK_KOLON = /(hazirlan|dogrulan|topla)/;

        const otomatikYakala = (liste) => {
            /* Panelde bulunan hazırlık/bankolu her siparişi kuyruğa at:
               arka plan zaten aynı imzayı tekrar yazmıyor, boşuna istek
               olmuyor. BILINEN filtresi kaldırıldı çünkü eski hatalı imzalı
               (ürünsüz) siparişleri "biliniyor" sayıp bir daha yazmıyordu. */
            const adaylar = liste.filter((s) => {
                if (!s || !s.siparisId) return false;
                if (otoSorulan.has(s.siparisId) || fetchQueueSet.has(s.siparisId)) return false;
                return !!s.banko || HAZIRLIK_KOLON.test(_turkce(s.kolon));
            });
            if (!adaylar.length) return;
            adaylar.slice(0, OTO_TUR_SINIRI).forEach((s) => {
                otoSorulan.add(s.siparisId);
                gonderilecek.add(s.siparisId);
                if (!fetchQueueSet.has(s.siparisId)) {
                    fetchQueue.push(s.siparisId);
                    fetchQueueSet.add(s.siparisId);
                }
            });
            if (adaylar.length && !isFetching) processQueue();
        };

        const siparisBul = (siparisId) => {
            for (var i = 0; i < sonSiparisListesi.length; i++) {
                if (sonSiparisListesi[i].siparisId === siparisId) return sonSiparisListesi[i];
            }
            return null;
        };

        /* Karttaki dört haneli kod siparişin kimliğinin sonu. Listede zaten
           tam kimlik var, eşleştirmek için ek istek atmaya gerek yok. */
        const kodaGoreSiparis = (kod) => {
            for (var i = 0; i < sonSiparisListesi.length; i++) {
                var id = String(sonSiparisListesi[i].siparisId || '');
                if (id.slice(-4) === kod) return sonSiparisListesi[i];
            }
            return null;
        };

        /* Sayfa köprüsü listeyi yalnız DEĞİŞTİĞİNDE yayınlıyor. Sonradan
           başlayan dinleyici o yayını kaçırıyor ve elinde liste olmuyordu.
           Bu mesaj yeniden yayın istiyor. */
        const listeyiIste = () => {
            try { window.postMessage({ type: 'JB_SIPARIS_SOR' }, location.origin); }
            catch (e) { /* sessiz */ }
        };

        /* Getir'in kartında iç içe tıklanabilir parçalar var; tek dokunuş iki
           click olayı üretebiliyor ve aynı sipariş iki kez yollanıyordu. Arka
           plan zaten aynı imzayı yazmıyor ama boşuna mesaj da gitmesin. */
        const sonGonderim = new Map();

        const siparisiYolla = (siparisId) => {
            var s = siparisBul(siparisId);
            /* Sipariş sonSiparisListesi'nde yoksa (henüz JB_SIPARISLER
               gelmedi ya da liste güncellendi) cache'ten asgari paket
               kur: en azından ürünler yazılsın. Background siparisYaz
               conditional gövde üretiyor, boş alanlar mevcut DB'yi bozmaz. */
            if (!s) {
                const kod = String(siparisId).slice(-4);
                const girdi = orderCache[kod];
                if (!girdi || Array.isArray(girdi) || !Array.isArray(girdi.detay) || !girdi.detay.length) return;
                s = { siparisId: siparisId, urunler: [] };
                if (girdi.toplayiciFoto) s.toplayiciFoto = girdi.toplayiciFoto;
                if (girdi.kuryeFoto) s.kuryeFoto = girdi.kuryeFoto;
            }
            var simdi = Date.now();
            /* 30 sn koruma: aynı sipariş için tekrar tekrar gönderim ve log
               spam'i azaltılır. Background başarıyla yazarsa yeter. */
            if (simdi - (sonGonderim.get(siparisId) || 0) < 30000) return;
            sonGonderim.set(siparisId, simdi);
            gonderilecek.delete(siparisId);
            var paket = birlestir(s);
            /* Ürün yoksa gönderme: DB'ye kunye yazılıp order_items boş kalırdı,
               site "Ürünler henüz gelmedi" gösterirdi. Detay geldiğinde
               tekrar denenir (gonderilecek.add + sonGonderim.delete). */
            if (!paket.urunler || !paket.urunler.length) {
                sonGonderim.delete(siparisId);
                gonderilecek.add(siparisId);
                /* Yalnız `gonderilecek`'e eklemek yetmiyordu: detay hiç
                   gelmediyse bu sipariş bir daha kuyruğa girmiyor ve
                   sonsuza kadar ürünsüz bekliyordu. Önbelleği düşürüp
                   kuyruğun başına alıyoruz ki taze detay çekilsin. */
                const kodY = String(siparisId).slice(-4);
                if (orderCache[kodY]) { delete orderCache[kodY]; saveCache(); }
                otoSorulan.delete(siparisId);
                /* Soğuma kontrolü olmadan burası bir döngü kuruyordu:
                   panel ürün vermeyen bir siparişi her seferinde yeniden
                   çektiriyordu. Panel ürünü verecek duruma gelince künye
                   imzası değişiyor ve soğuma orada kaldırılıyor. */
                if (!sogumadaMi(siparisId) && !fetchQueueSet.has(siparisId)) {
                    fetchQueue.unshift(siparisId);
                    fetchQueueSet.add(siparisId);
                    processQueue();
                }
                try {
                    var lg = JSON.parse(localStorage.getItem('jba_yazma_log') || '[]');
                    lg.push({ id: siparisId.slice(-4), urunSay: 0, sonuc: 'ATLA: urun_yok', saat: new Date().toLocaleTimeString('tr-TR') });
                    if (lg.length > 60) lg = lg.slice(-60);
                    localStorage.setItem('jba_yazma_log', JSON.stringify(lg));
                } catch (e) {}
                return;
            }
            var listedeVar = !!siparisBul(siparisId);
            var logKaydet = function (sonuc) {
                try {
                    var log = JSON.parse(localStorage.getItem('jba_yazma_log') || '[]');
                    log.push({
                        id: siparisId.slice(-4),
                        urunSay: (paket.urunler || []).length,
                        listeVar: listedeVar,
                        sonuc: sonuc,
                        saat: new Date().toLocaleTimeString('tr-TR')
                    });
                    if (log.length > 60) log = log.slice(-60);
                    localStorage.setItem('jba_yazma_log', JSON.stringify(log));
                } catch (e) {}
            };
            try {
                chrome.runtime.sendMessage(
                    { type: 'JBA_SIPARIS_YAZ', siparisler: [paket] },
                    function (yanit) {
                        if (chrome.runtime.lastError) {
                            /* Background service worker uyuyorsa mesaj yutulur.
                               Koruma iznini geri al ki bir sonraki turda yeniden
                               denensin, kullanıcı ürünsüz sipariş görmesin. */
                            sonGonderim.delete(siparisId);
                            gonderilecek.add(siparisId);
                            logKaydet('SW_UYKU: ' + (chrome.runtime.lastError.message || ''));
                            return;
                        }
                        if (yanit && yanit.ok === false) {
                            sonGonderim.delete(siparisId);
                            gonderilecek.add(siparisId);
                            logKaydet('BG_HATA: ' + (yanit.sebep || 'x'));
                            return;
                        }
                        /* "OK" değil: arka plan siparişi yalnız kuyruğa
                           aldı. Gerçek sonuç JBA_YAZMA_SONUC ile ayrı bir
                           satır olarak geliyor. */
                        logKaydet('kuyrukta · ' + (paket.urunler || []).length + ' ürün');
                    }
                );
            } catch (e) {
                sonGonderim.delete(siparisId);
                gonderilecek.add(siparisId);
                logKaydet('THROW: ' + ((e && e.message) || 'x'));
            }
        };

        /**
         * Kullanıcı bir sipariş kartına girdi.
         *
         * Eskiden her liste taramasından sonra bütün siparişler yollanıyordu.
         * Gerek yoktu: kullanıcı yalnız girdiği siparişi topluyor. Artık tetik
         * tıklama. Ayrıntı önbellekte yoksa önce kuyruğa alınıyor, geldiğinde
         * gönderim kendiliğinden oluyor. Arka plan zaten değişmeyen siparişi
         * tekrar yazmıyor, aynı sipariş iki kez açılsa da tek yazma oluyor.
         */
        const kartAcildi = (card) => {
            const kod = getShortCode(card);
            if (!kod) return;

            const s = kodaGoreSiparis(kod);
            const uzunId = (s && s.siparisId) || idMap[kod];
            if (!uzunId) {
                // Liste elimizde değil: yeniden yayın iste, kullanıcı tekrar girerse yakalarız.
                listeyiIste();
                return;
            }

            const girdi = orderCache[kod];
            const detayVar = girdi && !Array.isArray(girdi) && Array.isArray(girdi.detay) && girdi.detay.length;

            if (detayVar) { siparisiYolla(uzunId); return; }

            gonderilecek.add(uzunId);
            if (!fetchQueueSet.has(uzunId)) {
                /* Öne alınıyor: kullanıcının açtığı sipariş, arka planda
                   sıradaki başkalarını beklemesin. */
                fetchQueue.unshift(uzunId);
                fetchQueueSet.add(uzunId);
                if (!isFetching) processQueue();
            }
        };

        document.addEventListener('click', (e) => {
            const kart = e.target.closest && e.target.closest('[class*="orderCard--"]');
            if (kart) kartAcildi(kart);
        }, true);

        /* Jet Barkod sitesi "şu siparişlerin ürünü gelmemiş" diye haber
           yolladı (arka plan üzerinden). Kullanıcı telefonda ya da başka
           bir bilgisayarda olabilir; Getir'e istek atabilen tek yer burası.
           Kimlikleri kuyruğun başına alıp önbelleği düşürüyoruz ki taze
           detay çekilsin ve veritabanına ürünler yazılsın. */
        try {
            chrome.runtime.onMessage.addListener((istek) => {
                /* Arka plan gerçek yazma sonucunu bildiriyor. Eskiden log'a
                   yalnız "kuyruğa alındı" bilgisi düşüyordu ve o da "OK"
                   diye yazılıyordu; veritabanına hiç ürün yazılmasa bile
                   log temiz görünüyordu. */
                if (istek && istek.type === 'JBA_YAZMA_SONUC') {
                    const kotu = /YAZILAMADI|EKSİK/.test(String(istek.sonuc || ''));
                    try {
                        let lg = JSON.parse(localStorage.getItem('jba_yazma_log') || '[]');
                        lg.push({
                            id: String(istek.siparisId || '').slice(-4),
                            sonuc: istek.sonuc,
                            saat: new Date().toLocaleTimeString('tr-TR')
                        });
                        if (lg.length > 60) lg = lg.slice(-60);
                        localStorage.setItem('jba_yazma_log', JSON.stringify(lg));
                    } catch (e) {}
                    /* Eksik ya da başarısız yazımda sipariş yeniden
                       gönderilebilsin: koruma süresi kalkıyor. */
                    if (kotu && istek.siparisId) {
                        sonGonderim.delete(istek.siparisId);
                        gonderilecek.add(istek.siparisId);
                    }
                    return;
                }
                if (!istek || istek.type !== 'JBA_URUN_CEK') return;
                const idler = Array.isArray(istek.siparisler) ? istek.siparisler : [];
                let eklendi = 0;
                idler.forEach((id) => {
                    if (typeof id !== 'string' || !id) return;
                    const kod = id.slice(-4);
                    if (orderCache[kod]) { delete orderCache[kod]; }
                    otoSorulan.delete(id);
                    sonGonderim.delete(id);
                    gonderilecek.add(id);
                    if (!fetchQueueSet.has(id)) {
                        fetchQueue.unshift(id);
                        fetchQueueSet.add(id);
                        eklendi++;
                    }
                });
                if (eklendi) { saveCache(); if (!isFetching) processQueue(); }
            });
        } catch (e) { /* sessiz */ }

        // === MESAJ DİNLEYİCİ ===
        /* SIFIRLAMA
           Panelle veritabanı birbirine girdiğinde elle basılan düğme.
           Konsol komutları MAIN world'de (`sayfa-koprusu.js`), asıl iş
           burada: `chrome.runtime` yalnız bu tarafta var.

           Neyi silmek gerekiyor: yalnız önbelleği silmek yetmiyor. İki
           defter daha "bunu zaten hallettim" diyor ve aynı siparişin
           yeniden çekilmesini engelliyor: bellekteki `otoSorulan`,
           `sonKunye`, `urunsuzSoguma` gibi kümeler ve arka plandaki imza
           defteri. Üçü birden temizlenmezse sıfırlama işe yaramıyor. */
        const durumuSifirla = () => {
            orderCache = {};
            fetchQueue = [];
            fetchQueueSet.clear();
            otoSorulan.clear();
            gonderilecek.clear();
            sonKunye.clear();
            sonKisi.clear();
            sonGonderim.clear();
            urunsuzSoguma.clear();
            denemeler.clear();
            try { localStorage.removeItem('getir_order_cache'); } catch (e) {}
            try { localStorage.removeItem('jba_yazma_log'); } catch (e) {}
        };

        const sifirlamayiYurut = (dbdeSil) => {
            durumuSifirla();
            try {
                chrome.runtime.sendMessage(
                    { type: 'JBA_SIPARIS_SIFIRLA', dbdeSil: !!dbdeSil },
                    (yanit) => {
                        const hata = chrome.runtime.lastError;
                        window.postMessage({
                            type: 'JB_JBA_SIFIRLA_SONUC',
                            ok: !hata && !!(yanit && yanit.ok),
                            db: !!dbdeSil,
                            sebep: hata ? hata.message : (yanit && yanit.sebep) || ''
                        }, location.origin);
                        /* Defterler boş; panel bir sonraki duyuruda her
                           siparişi "yeni" sayıp baştan çekecek. Beklemeden
                           duyuru istiyoruz. */
                        try { window.postMessage({ type: 'JB_SIPARIS_SOR' }, location.origin); } catch (e) {}
                    }
                );
            } catch (e) {
                window.postMessage({ type: 'JB_JBA_SIFIRLA_SONUC', ok: false, sebep: (e && e.message) || 'hata' }, location.origin);
            }
        };

        window.addEventListener('message', (event) => {
            if (!event.data || event.source !== window) return;
            if (event.data.type === 'JB_JBA_SIFIRLA') {
                sifirlamayiYurut(event.data.dbdeSil);
                return;
            }
            if (event.data.type === 'JB_SIPARISLER' && Array.isArray(event.data.liste)) {
                sonSiparisListesi = event.data.liste;
                /* `ilk`: panel sayfası yeni açıldı ya da sekmeye dönüldü.
                   Temizlik kilidini atlayıp tam senkron istiyoruz; saatler
                   sonra dönüldüğünde eski kayıtlar bir an bile durmasın. */
                kunyeleriYolla(sonSiparisListesi, !!event.data.ilk);
                otomatikYakala(sonSiparisListesi);
                /* Detay processQueue içinde çekilmiş ama o an sipariş henüz
                   sonSiparisListesi'nde yoktu diye siparisiYolla no-op
                   olmuş olabilir. Şimdi liste güncel, bekleyen ne varsa
                   gönderelim ki DB'ye ürün satırları yazılsın. */
                sonSiparisListesi.forEach((s) => {
                    if (!s || !s.siparisId) return;
                    const kod = String(s.siparisId).slice(-4);
                    const girdi = orderCache[kod];
                    const detayVar = girdi && !Array.isArray(girdi) && Array.isArray(girdi.detay) && girdi.detay.length;
                    if (detayVar) siparisiYolla(s.siparisId);
                });
            }
            if (event.data.type === 'GETIR_DATA_RECEIVED') findOrderIds(event.data.payload);
            if (event.data.type === 'GETIR_TOKEN_CAPTURED') {
                const t = event.data.token;
                if (t && t !== userToken) {
                    userToken = t;
                    localStorage.setItem('getir_manual_token', t);
                    const el = document.getElementById('jba-hb-jeton-durum');
                    if (el) el.innerText = getTokenExpiry(t);
                    if (!isFetching && fetchQueue.length > 0) processQueue();
                }
            }
        });

        // === OBSERVER (debounce + widget-dışı filtre) ===
        let obDebounce = null;
        const observer = new MutationObserver((mutations) => {
            const hasExternal = mutations.some(m => {
                if (m.type !== 'childList') return false;
                let node = m.target;
                while (node && node !== document.body) {
                    if (node.id === 'jba-hb') return false;
                    node = node.parentNode;
                }
                return true;
            });
            if (!hasExternal) return;
            clearTimeout(obDebounce);
            obDebounce = setTimeout(() => { checkAndSync(); applyUI(); }, 300);
        });

        // === DIŞARI TIKLAMA / ESC ===
        /* Aramadan siparişe geçince panel açık kalıyordu. Kartın kendisine
           tıklamak da dışarı tıklamak sayılıyor, o yüzden sonuçtan siparişe
           gidince panel kendiliğinden kapanıyor. */
        document.addEventListener('click', (e) => {
            if (!panelAcikMi()) return;
            const kap = document.getElementById('jba-hb');
            if (!kap) return;
            if (kap.contains(e.target)) return;
            paneliKapat();
        }, true);

        document.addEventListener('keydown', (e) => {
            if (e.key !== 'Escape' || !panelAcikMi()) return;
            paneliKapat();
        });

        // === YAŞAM DÖNGÜSÜ ===
        /*
         * Eklenti başka sekmeye gidip dönünce ölüyordu. Sebep tarayıcı sekmesi
         * değil, panelin kendi içindeki gezinme: içerik betiği sayfa başına bir
         * kez çalışıyor, React sipariş ekranından çıkınca kabuğu söküyor ve
         * geri dönüldüğünde kimse yeniden kurmuyordu. Nöbetçi hem adresi hem
         * kabuğun varlığını denetliyor.
         */
        const yolUygun = () => SIPARIS_YOLU.test(location.pathname);

        const nobet = () => {
            if (!yolUygun()) {
                const k = document.getElementById('jba-hb');
                if (k) k.style.display = 'none';
                return false;
            }
            if (!document.getElementById('jba-hb')) buildWidget();
            const k = document.getElementById('jba-hb');
            if (k) k.style.display = '';
            return true;
        };

        /* Sipariş ekranına dönüldüğü an yeni siparişleri de yakala; kullanıcı
           akışı kaybetmesin diye radar bir kez zorlanıyor. */
        const geriDondu = () => {
            if (!nobet()) return;
            checkAndSync();
            applyUI();
            forceRadarFetch();
            listeyiIste();
        };

        const adresiIzle = () => {
            var sonYol = location.pathname;
            const bak = () => {
                if (location.pathname === sonYol) return;
                sonYol = location.pathname;
                geriDondu();
            };
            ['pushState', 'replaceState'].forEach((ad) => {
                const asil = history[ad];
                if (typeof asil !== 'function' || asil.__jbSarildi) return;
                const sarmal = function () {
                    const r = asil.apply(this, arguments);
                    setTimeout(bak, 0);
                    return r;
                };
                sarmal.__jbSarildi = true;
                history[ad] = sarmal;
            });
            window.addEventListener('popstate', () => setTimeout(bak, 0));
            setInterval(bak, 1000);   // yalnız dize karşılaştırması, ölçülebilir yük yok
        };

        // === INIT ===
        /* YETİM BAĞLAM AĞI
           Eklenti güncellenince ya da devre dışı bırakılıp açılınca bu
           içerik betiği yetim kalır: chrome.runtime.id tanımsız olur ve
           bütün mesajlar sessizce düşer. Sayfa normal görünmeye devam
           ettiği için kimse fark etmez, veri akışı saatlerce durur.

           Arka plan güncelleme anında panoyu zaten yeniliyor. Bu ağ o
           yolun tutmadığı hâller için: tarayıcı çökmesi, eklentinin elle
           kapatılıp açılması, yenilemenin engellendiği durumlar. */
        let yetimUyarisiVerildi = false;

        const baglamGecerliMi = () => {
            try { return !!(chrome.runtime && chrome.runtime.id); }
            catch (e) { return false; }
        };

        const yetimKaldiysaTazele = () => {
            if (baglamGecerliMi() || yetimUyarisiVerildi) return false;
            yetimUyarisiVerildi = true;
            /* Kullanıcı sayfanın neden yenilendiğini görsün diye kısa bir
               şerit gösterilip 4 saniye sonra yenileniyor. Pano salt
               okunur, yenileme veri kaybettirmiyor. */
            try {
                const s = document.createElement('div');
                s.textContent = 'Jet Barkod Asistan güncellendi, panel tazeleniyor…';
                s.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:2147483647;' +
                    'background:#131720;color:#fff;font:600 13px/1.4 system-ui,sans-serif;' +
                    'padding:10px 14px;text-align:center';
                document.documentElement.appendChild(s);
            } catch (e) { /* sessiz */ }
            setTimeout(() => { try { location.reload(); } catch (e) {} }, 4000);
            return true;
        };

        const init = () => {
            nobet();
            listeyiIste();
            observer.observe(document.body, { childList: true, subtree: true });
            adresiIzle();

            document.addEventListener('visibilitychange', () => {
                if (document.visibilityState === 'visible') {
                    if (yetimKaldiysaTazele()) return;
                    geriDondu();
                }
            });
            window.addEventListener('focus', () => {
                if (yetimKaldiysaTazele()) return;
                geriDondu();
            });

            setInterval(() => {
                if (yetimKaldiysaTazele()) return;
                if (!nobet()) return;
                checkAndSync();
                applyUI();
                const el = document.getElementById('jba-hb-jeton-durum');
                if (el) el.innerText = getTokenExpiry(userToken);
            }, 5000);
        };

        setTimeout(init, 1500);
    }

    JBA.kayit({
        kimlik: 'hizliBul',
        ad: 'Hızlı Bul',
        ozet: 'Sipariş kartlarının içindeki ürünleri anında arar, kategorilere göre renklendirir.',
        hostlar: ['warehouse.getir.com'],
        /* Yol kapısı kaldırıldı. Kullanıcı panelin başka bir sekmesinde
           açılıp sonra siparişlere geçtiğinde modül hiç kurulmuyordu; artık
           kurulup görünürlüğü kendi yönetiyor. */

        baslat: function () {
            calistir();
        },

        durdur: function () {
            var w = document.getElementById('jba-hb');
            if (w) w.remove();
            JBA.bildir('Hızlı Bul kapandı, sayfayı yenile.', null);
        },

        eylemler: [
            { ad: 'Arama kutusuna git', calistir: function () {
                var g = document.getElementById('jba-hb-girdi');
                if (g) { g.scrollIntoView({ block: 'center' }); g.focus(); }
                else JBA.bildir('Arama kutusu bu sayfada yok.', 'olumsuz');
            } }
        ]
    });
})(window);

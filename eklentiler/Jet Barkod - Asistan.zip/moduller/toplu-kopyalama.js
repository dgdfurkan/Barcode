/**
 * Modül: Toplu Kopyalama
 * ============================================================================
 *
 * warehouse.getir.com sipariş panelinde ürün tablolarına kopyalama düğmesi
 * ekler. Satır başına küçük bir düğme, tablonun üstüne de "Tümünü Kopyala".
 * Sipariş kartının boş bir yerine tıklamak da "Tümünü Kopyala" yapar.
 * Kopyalanan HTML, Jet Barkod arama kutusuna yapıştırılınca barkoda ve
 * görsele çözülüyor.
 *
 * Kaynağı `getir-warehouse-html-copy-extension/content.js`. Ürün satırı
 * tanıma mantığı birebir korundu; sahada çalışan kısım orası ve Getir
 * panelinin sınıf isimlerine bağlı. Değişen yerler:
 *
 *   - Kendi MutationObserver'ı yok, çekirdeğin tek gözlemcisine abone.
 *   - Kendi bildirim kutusu yok, çekirdeğin bildirimi.
 *   - Kendi pano yardımcısı yok, çekirdeğinki (yedekli).
 *   - Sınıf adları `jba-` önekine alındı. Sayfaya sızan tek şey bu iki
 *     düğmenin stili; tablo satırının içinde durdukları için gölge DOM'a
 *     alınamıyor, o yüzden önek şart.
 * ============================================================================
 */
(function (global) {
    'use strict';

    var JBA = global.JBA;
    if (!JBA) return;

    var SITE = 'https://jetbarkod.com.tr/arama/';
    var YONLENDIR_ANAHTARI = 'getirAutoRedirect';

    var STIL = [
        '.jba-satir-kopyala {',
        '  opacity: 0.4; transition: opacity 0.2s; font-size: 11px; padding: 2px 6px;',
        '  border: 1px solid #ddd; background: #f5f5f5; border-radius: 3px;',
        '  cursor: pointer; margin-left: 5px; color: #666; font-weight: normal; }',
        '.jba-satir-kopyala:hover {',
        '  opacity: 1; background: #e8f4f8; border-color: #4a90e2; color: #4a90e2; }',
        '.jba-tum-kopyala {',
        '  opacity: 0.6; padding: 4px 10px; font-size: 12px; border: 1px solid #4a90e2;',
        '  background: #e8f4f8; color: #4a90e2; border-radius: 4px; cursor: pointer;',
        '  margin: 5px; font-weight: 500; }',
        '.jba-tum-kopyala:hover { opacity: 1; background: #4a90e2; color: #fff; }',
        '.jba-tum-kap { display: flex; justify-content: flex-end; padding: 5px; margin-bottom: 10px; }'
    ].join('\n');

    function stilKur() {
        if (document.getElementById('jba-toplu-kopyalama-stil')) return;
        var s = document.createElement('style');
        s.id = 'jba-toplu-kopyalama-stil';
        s.textContent = STIL;
        (document.head || document.documentElement).appendChild(s);
    }

    // ==================================================================
    // Yönlendirme tercihi
    // ==================================================================

    function yonlendirmeAcikMi() {
        return new Promise(function (coz) {
            try {
                chrome.storage.local.get(YONLENDIR_ANAHTARI, function (r) {
                    var d = r && r[YONLENDIR_ANAHTARI];
                    coz(d === true || d === 'true');
                });
            } catch (e) { coz(false); }
        });
    }

    /**
     * Jet Barkod'a geçer. Açık sekme varsa onu öne alır.
     *
     * ÖNCE ARKA PLAN. Arka plan `tabs` yetkisiyle sekmeyi doğrudan görüyor,
     * beklemeye gerek kalmıyor. Eski yol (BroadcastChannel ile "ping" atıp
     * yarım saniye "pong" beklemek) yedek olarak duruyor: arka plan cevap
     * vermezse (eklenti güncellenirken içerik betiği yetim kalabiliyor)
     * eskisi gibi çalışıyor.
     *
     * Eski yolun sorunu şuydu: Chrome sekmeyi bellek için kapattıysa ya da
     * sekme o an meşgulse cevap gelmiyor ve İKİNCİ bir sekme açılıyordu;
     * kullanıcı sayfanın yeniden yüklenmesini bekliyordu.
     */
    function eskiYoldanGit(yalnizAcik) {
        try {
            if (typeof BroadcastChannel !== 'undefined') {
                var kanal = new BroadcastChannel('barcode_site_nav');
                var cevap = false;
                var dinle = function (e) {
                    if (e.data && e.data.type === 'pong') cevap = true;
                };
                kanal.addEventListener('message', dinle);
                kanal.postMessage({ type: 'ping', url: SITE });
                setTimeout(function () {
                    kanal.removeEventListener('message', dinle);
                    kanal.close();
                    if (!cevap && !yalnizAcik) window.open(SITE, '_blank');
                }, 700);
                return;
            }
        } catch (e) { /* kanal yoksa aşağıdaki yol */ }
        if (!yalnizAcik) window.open(SITE, '_blank');
    }

    /* Asistan ayarı "Kopyalayınca Aramaya Geç": yalnız AÇIK arama sekmesine
       geçilir, yoksa yeni sekme açılmaz (kullanıcı isteği). Arka plan cevap
       vermezse eski yol (BroadcastChannel) da açık sekme yoksa bir şey açmaz. */
    function siteyeGit() {
        try {
            chrome.runtime.sendMessage({ type: 'JBA_SITEYE_GIT', url: SITE, yalnizAcik: true }, function (cevap) {
                if (chrome.runtime.lastError || !cevap || !cevap.ok) {
                    eskiYoldanGit(true);
                }
            });
        } catch (e) {
            eskiYoldanGit(true);
        }
    }

    /* Kopyalama bitti, beklemeye gerek yok. Eskiden yarım saniye bekleniyor,
       ardından yarım saniye de "pong" bekleniyordu; sekme diri olsa bile bir
       saniye kaybediliyordu. Panoya yazma zaten tamamlandı; kısa gecikme
       yalnız "kopyalandı" bildiriminin görünmesi için. */
    function kopyalandiktanSonra() {
        yonlendirmeAcikMi().then(function (acik) {
            if (acik) setTimeout(siteyeGit, 60);
        });
    }

    // ==================================================================
    // Ürün satırı tanıma. Getir panelinin Ant Design yapısına bağlı.
    // ==================================================================

    var ATLA = ['müşteri adı', 'müşteri notu', 'teslimat adresi', 'adres açıklaması',
                'toplayıcı adı', 'kurye adı', 'poşet kullanımı', 'durum', 'lokasyonlar',
                'müşteri', 'kurye', 'toplayıcı', 'adres', 'teslimat', 'notu'];

    function urunTablosuMu(tablo) {
        if (tablo.closest('.ant-descriptions')) return false;
        if (tablo.closest('.ant-descriptions-view')) return false;
        var sarmal = tablo.closest('.ant-table-wrapper, .ant-table-container');
        if (!sarmal && !tablo.classList.contains('ant-table')) {
            if (!tablo.closest('.ant-row .ant-col')) return false;
        }
        return true;
    }

    function urunSatiriMi(tr) {
        if (tr.closest('.ant-descriptions')) return false;
        if (tr.classList.contains('ant-descriptions-row')) return false;
        if (tr.closest('.ant-descriptions-view')) return false;

        var hucreler = tr.querySelectorAll('td');
        var metin = Array.prototype.map.call(hucreler, function (h) {
            return h.textContent.trim();
        }).join(' ').toLowerCase();
        for (var i = 0; i < ATLA.length; i++) {
            if (metin.includes(ATLA[i])) return false;
        }

        var gorsel = tr.querySelector(
            'img[src*="product"], img[src*="getir.com/product"], img[src*="getir.com/market/product"],' +
            ' img[src*="market/product"], img[src*="cdn-image.getir.com"]');
        if (!gorsel) {
            var ant = tr.querySelector('.ant-image img');
            if (!ant || !ant.src) return false;
            if (!ant.src.includes('product') && !ant.src.includes('getir')) return false;
        }

        return Array.prototype.some.call(hucreler, function (h) {
            var t = h.textContent.trim();
            return t && t.length > 2 && !/^\d+$/.test(t);
        });
    }

    function satirKabi(kok) {
        var satirlar = (kok || document).querySelectorAll('.ant-row');
        for (var i = 0; i < satirlar.length; i++) {
            var s = satirlar[i];
            if (s.closest('.ant-descriptions')) continue;
            var trler = s.querySelectorAll('table tbody tr');
            for (var j = 0; j < trler.length; j++) {
                var tr = trler[j];
                if (tr.querySelector('img') || tr.querySelector('.ant-image img')) return s;
                var hucreler = tr.querySelectorAll('td');
                var adVar = Array.prototype.some.call(hucreler, function (h) {
                    var t = (h.textContent || '').trim();
                    return t.length > 2 && !/^\d+$/.test(t) &&
                           !t.includes('Ürün Adı') && !t.includes('Adet');
                });
                if (adVar) return s;
            }
        }
        return null;
    }

    // ==================================================================
    // Kopyalama
    // ==================================================================

    function satirKopyala(tr) {
        // Tek satır kopyası sekme değiştirmez; geçiş yalnız Tümünü Kopyala'da
        JBA.panoyaYaz(tr.outerHTML).then(function (oldu) {
            if (!oldu) return JBA.bildir('Kopyalanamadı, tekrar dene.', 'olumsuz');
            JBA.bildir('Ürün kopyalandı.', 'olumlu');
        });
    }

    function tumunuKopyala(kok) {
        // Eylem menüsünden çağrılınca ilk değişken bir DOM öğesi olmayabilir
        if (!kok || typeof kok.querySelectorAll !== 'function') kok = null;
        var html = null;
        var kap = satirKabi(kok);
        if (kap) {
            html = kap.outerHTML;
        } else {
            var govde = kok || document.querySelector('.ant-modal .ant-modal-body');
            if (govde) html = govde.innerHTML;
        }
        if (!html) return JBA.bildir('Ürün tablosu bulunamadı.', 'olumsuz');

        JBA.panoyaYaz(html).then(function (oldu) {
            if (!oldu) return JBA.bildir('Kopyalanamadı, tekrar dene.', 'olumsuz');
            var adet = kap
                ? kap.querySelectorAll('tbody tr.ant-table-row').length
                : (html.match(/ant-table-row/g) || html.match(/<tr/g) || []).length;
            JBA.bildir(adet > 0 ? adet + ' ürün kopyalandı.' : 'Liste kopyalandı.', 'olumlu');
            kopyalandiktanSonra();
        });
    }

    // ==================================================================
    // Düğmeleri yerleştir
    // ==================================================================

    function satiraDugme(tr) {
        if (tr.querySelector('.jba-satir-kopyala')) return;
        if (!urunSatiriMi(tr)) return;

        var d = document.createElement('button');
        d.type = 'button';
        d.className = 'jba-satir-kopyala';
        d.textContent = '📋';
        d.title = 'Bu ürünü kopyala';
        d.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            satirKopyala(tr);
        });

        var hucreler = tr.querySelectorAll('td');
        if (hucreler.length) {
            var son = hucreler[hucreler.length - 1];
            if (!son.querySelector('.jba-satir-kopyala')) {
                son.style.position = 'relative';
                son.appendChild(d);
            }
        } else {
            var yeni = document.createElement('td');
            yeni.appendChild(d);
            tr.appendChild(yeni);
        }
    }

    function tumunuDugmesi() {
        var satirlar = document.querySelectorAll('.ant-row');
        for (var i = 0; i < satirlar.length; i++) {
            var satir = satirlar[i];
            if (satir.closest('.ant-descriptions')) continue;

            var urunVar = false;
            var sutunlar = satir.querySelectorAll('.ant-col');
            for (var j = 0; j < sutunlar.length && !urunVar; j++) {
                var tablolar = sutunlar[j].querySelectorAll('table');
                for (var k = 0; k < tablolar.length && !urunVar; k++) {
                    if (!urunTablosuMu(tablolar[k])) continue;
                    var trler = tablolar[k].querySelectorAll('tbody tr');
                    for (var m = 0; m < trler.length; m++) {
                        if (urunSatiriMi(trler[m])) { urunVar = true; break; }
                    }
                }
            }
            if (!urunVar) continue;

            var ust = satir.parentNode;
            if (!ust || ust.querySelector('.jba-tum-kap')) continue;

            var kap = document.createElement('div');
            kap.className = 'jba-tum-kap';
            var d = document.createElement('button');
            d.type = 'button';
            d.className = 'jba-tum-kopyala';
            d.textContent = '📋 Tümünü Kopyala';
            d.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                tumunuKopyala();
            });
            kap.appendChild(d);
            ust.insertBefore(kap, satir);
        }
    }

    // ==================================================================
    // Sipariş kartının boş bir yerine tıklamak = Tümünü Kopyala
    // ==================================================================

    // Kart, başlığıyla birlikte bütün modal. Kendi işi olan öğeler: görsel
    // büyütme, başlıktaki sipariş kimliği (ant-tag), "Şüpheli Ol" ve diğer
    // düğmeler. Bunlara tıklanınca kopyalama yapılmaz.
    var ETKILESIMLI = 'a, button, input, textarea, select, option, label, img, svg, video,' +
        ' [role="button"], [role="link"], [role="checkbox"], [role="switch"], [role="tab"],' +
        ' [role="menuitem"], [role="combobox"], [contenteditable=""], [contenteditable="true"],' +
        ' .ant-btn, .ant-image, .ant-typography-copy, .ant-select, .ant-checkbox-wrapper,' +
        ' .ant-radio-wrapper, .ant-switch, .ant-dropdown-trigger, .ant-modal-close,' +
        ' .ant-pagination, .ant-tag, .jba-satir-kopyala, .jba-tum-kap';

    var sonKartKopyasi = 0;

    function etkilesimliMi(hedef, govde) {
        for (var el = hedef; el && el !== govde; el = el.parentElement) {
            if (el.nodeType !== 1) continue;
            if (el.matches(ETKILESIMLI)) return true;
            // Panel tıklanabilir öğelere el imleci veriyor (sipariş kimliği gibi)
            if (global.getComputedStyle(el).cursor === 'pointer') return true;
        }
        return false;
    }

    function kartTiklandi(e) {
        if (e.button !== 0 || e.defaultPrevented) return;
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
        var hedef = e.target && e.target.nodeType === 1 ? e.target : e.target && e.target.parentElement;
        if (!hedef) return;
        var govde = hedef.closest('.ant-modal-content');
        if (!govde || etkilesimliMi(hedef, govde)) return;
        // Metin seçmek için sürüklendiyse kopyalama yapılmaz
        var secim = global.getSelection ? String(global.getSelection()) : '';
        if (secim.trim()) return;
        if (!satirKabi(govde)) return;
        var simdi = Date.now();
        if (simdi - sonKartKopyasi < 800) return;
        sonKartKopyasi = simdi;
        tumunuKopyala(govde);
    }

    function tara() {
        tumunuDugmesi();
        var gorulen = [];
        var satirlar = document.querySelectorAll('.ant-row');
        for (var i = 0; i < satirlar.length; i++) {
            if (satirlar[i].closest('.ant-descriptions')) continue;
            var sutunlar = satirlar[i].querySelectorAll('.ant-col');
            for (var j = 0; j < sutunlar.length; j++) {
                var tablolar = sutunlar[j].querySelectorAll('table');
                for (var k = 0; k < tablolar.length; k++) {
                    var t = tablolar[k];
                    if (gorulen.indexOf(t) > -1 || !urunTablosuMu(t)) continue;
                    gorulen.push(t);
                    var trler = t.querySelectorAll('tbody tr');
                    for (var m = 0; m < trler.length; m++) satiraDugme(trler[m]);
                }
            }
        }
    }

    // ==================================================================

    JBA.kayit({
        kimlik: 'topluKopyalama',
        ad: 'Toplu Kopyalama',
        ozet: 'Sipariş tablolarına kopyalama düğmesi ekler. Kopyalananı Jet Barkod arama kutusuna yapıştır.',
        hostlar: ['warehouse.getir.com'],
        yol: function (yol) { return yol.includes('/dashboard/orders'); },

        baslat: function (ctx) {
            stilKur();
            tara();
            // Getir paneli tek sayfa uygulaması: tablo sonradan geliyor,
            // modal açılıp kapanıyor. Tek gözlemci her değişiklikte tarıyor.
            this._birak = ctx.izle(tara);
            document.addEventListener('click', kartTiklandi);
        },

        durdur: function () {
            if (this._birak) this._birak();
            document.removeEventListener('click', kartTiklandi);
            document.querySelectorAll('.jba-satir-kopyala, .jba-tum-kap').forEach(function (e) { e.remove(); });
        },

        eylemler: [
            { ad: 'Tümünü kopyala', calistir: tumunuKopyala }
        ]
    });
})(window);

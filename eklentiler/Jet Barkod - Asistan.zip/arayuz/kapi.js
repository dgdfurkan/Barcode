/**
 * Jet Barkod Asistan. Araç çubuğu paneli.
 * ============================================================================
 *
 * Chrome'un eklenti simgesine tıklanınca açılıyor. Etkin sekmeye "hangi
 * modüller çalışıyor" diye soruyor ve listeliyor. Modülün eylemleri varsa
 * düğme olarak çıkıyor; basınca sekmedeki modül çalıştırılıyor.
 *
 * NEDEN BURADA
 * Önceki sürümde bu bilgi sayfanın sağ altında sürekli duran yüzen bir
 * düğmedeydi. Her sayfada yer kaplıyor, gözü yoruyordu. Buraya taşınınca
 * eklenti sayfaya hiçbir şey koymuyor; bilgi lazım olduğunda kullanıcı
 * simgeye basıyor.
 *
 * CEVAP GELMEZSE
 * Getir dışındaki sayfalarda içerik betiği hiç çalışmıyor, dolayısıyla
 * mesaja kimse cevap vermiyor. Bu bir hata değil, beklenen durum;
 * kullanıcıya "bu sayfada çalışmıyor" diye anlatılıyor.
 * ============================================================================
 */
(function () {
    'use strict';

    var govde = document.getElementById('govde');
    var rozet = document.getElementById('rozet');
    var yerEl = document.getElementById('yer');
    var surumEl = document.getElementById('surum');

    var DESTEKLENEN = ['warehouse.getir.com', 'franchise.getir.com', 'franchise-v2.getir.com'];

    try {
        surumEl.textContent = 'sürüm ' + chrome.runtime.getManifest().version;
    } catch (e) { /* sessiz */ }

    function yaz(dugum) {
        govde.innerHTML = '';
        govde.appendChild(dugum);
    }

    function bosMesaj(metin) {
        var p = document.createElement('p');
        p.className = 'bos';
        p.textContent = metin;
        return p;
    }

    function rozetYaz(metin, sinif) {
        rozet.textContent = metin === 'yok' ? 'Modül yok' : metin + ' açık';
        rozet.className = 'rozet' + (sinif ? ' ' + sinif : '');
        var oz = document.getElementById('durumOzet');
        if (oz) oz.textContent = metin === 'yok' ? 'Bu sayfada modül yok' : metin + ' modül açık';
        document.body.classList.toggle('sayfa-acik', metin !== 'yok');
    }

    /** Tek modül satırı. */
    function modulSatiri(m) {
        var kap = document.createElement('div');
        kap.className = 'modul';

        var ust = document.createElement('div');
        ust.className = 'modul__ust';

        var durumSinifi = m.hata ? 'bozuk' : (m.calisiyor ? 'acik' : '');

        var nokta = document.createElement('span');
        nokta.className = 'nokta' + (durumSinifi ? ' ' + durumSinifi : '');

        var ad = document.createElement('span');
        ad.className = 'modul__ad';
        ad.textContent = m.ad;

        var durum = document.createElement('span');
        durum.className = 'modul__durum' + (durumSinifi ? ' ' + durumSinifi : '');
        durum.textContent = m.hata ? 'hata' : (m.calisiyor ? 'açık' : 'kapalı');

        ust.appendChild(nokta);
        ust.appendChild(ad);
        ust.appendChild(durum);
        kap.appendChild(ust);

        var ozet = document.createElement('p');
        ozet.className = 'modul__ozet';
        ozet.textContent = m.hata
            ? 'Bu modül hata verdi, diğerleri çalışmaya devam ediyor.'
            : (m.calisiyor ? m.ozet : (m.izinli === false ? 'Bu hak hesabında kapalı.' : 'Sayfa yüklenince uyanır.'));
        kap.appendChild(ozet);

        if (m.calisiyor && m.eylemler && m.eylemler.length) {
            var eylemler = document.createElement('div');
            eylemler.className = 'eylemler';
            m.eylemler.forEach(function (ad2, i) {
                var d = document.createElement('button');
                d.type = 'button';
                d.className = 'eylem';
                d.textContent = ad2;
                d.addEventListener('click', function () {
                    d.disabled = true;
                    eylemCalistir(m.kimlik, i, function () {
                        // Eylem sekmede çalışıyor; paneli kapatınca kullanıcı
                        // sonucu sayfada görüyor.
                        window.close();
                    });
                });
                eylemler.appendChild(d);
            });
            kap.appendChild(eylemler);
        }

        return kap;
    }

    function etkinSekme(devam) {
        chrome.tabs.query({ active: true, currentWindow: true }, function (sekmeler) {
            devam(sekmeler && sekmeler[0]);
        });
    }

    function eylemCalistir(kimlik, sira, bitince) {
        etkinSekme(function (sekme) {
            if (!sekme) return bitince();
            chrome.tabs.sendMessage(sekme.id,
                { type: 'JBA_EYLEM_CALISTIR', kimlik: kimlik, eylem: sira },
                function () { void chrome.runtime.lastError; bitince(); });
        });
    }

    function ciz(durum) {
        /* Yalnız bu sayfada çalışan modüller. Eskiden host'taki bütün modüller
           listeleniyordu; kontrol panelinde Fırın Pişirme "kapalı, hak yok"
           görünüyordu, oysa yalnız fırın sayfasında uyanıyor. */
        var moduller = ((durum && durum.moduller) || []).filter(function (m) {
            return m.buSayfada !== false || m.calisiyor;
        });
        var acik = moduller.filter(function (m) { return m.calisiyor; }).length;
        var bozukVar = moduller.some(function (m) { return m.hata; });

        if (!moduller.length) {
            rozetYaz('yok', 'bos');
            return yaz(bosMesaj('Bu sayfada çalışan modül yok. Modüller yalnız ' +
                                'ilgili Getir panellerinde uyanır.'));
        }

        rozetYaz(acik + ' / ' + moduller.length, bozukVar ? 'bozuk' : null);

        var liste = document.createElement('div');
        moduller.forEach(function (m) { liste.appendChild(modulSatiri(m)); });
        yaz(liste);
    }

    etkinSekme(function (sekme) {
        if (!sekme || !sekme.url) {
            rozetYaz('yok', 'bos');
            return yaz(bosMesaj('Sekme okunamadı.'));
        }

        var adres;
        try { adres = new URL(sekme.url).hostname; } catch (e) { adres = ''; }
        yerEl.textContent = adres || sekme.url;

        chrome.tabs.sendMessage(sekme.id, { type: 'JBA_DURUM_SOR' }, function (cevap) {
            // Cevap gelmemesi hata değil: desteklenmeyen sayfada içerik
            // betiği hiç çalışmıyor. lastError okunmazsa konsola uyarı düşer.
            var kopuk = chrome.runtime.lastError;
            void kopuk;

            if (cevap) return ciz(cevap);

            rozetYaz('yok', 'bos');
            if (DESTEKLENEN.indexOf(adres) > -1) {
                yaz(bosMesaj('Sayfa henüz yüklenmemiş olabilir. Sekmeyi yenileyip tekrar dene.'));
            } else {
                yaz(bosMesaj('Asistan bu sayfada çalışmıyor. Getir depo ya da franchise ' +
                             'panelinde aç.'));
            }
        });
    });

    /* Fırın bildirimi sıklığı (arka-plan/firin-nobet.js okuyor) */
    var firinAyar = document.getElementById('firinAyar');
    if (firinAyar) {
        chrome.storage.local.get('jbaFirinNobet', function (r) {
            var a = (r && r.jbaFirinNobet) || {};
            // Eski kayıt dakika tutuyordu; saniyesi yoksa yeni varsayılan 15 sn
            var sn = Number(a.sn) > 0 ? Number(a.sn) : 15;
            firinAyar.value = a.acik === false ? '0' : String(sn);
            if (!firinAyar.value) firinAyar.value = '15';
        });
        firinAyar.addEventListener('change', function () {
            var sn = parseInt(firinAyar.value, 10) || 0;
            chrome.storage.local.set({ jbaFirinNobet: sn ? { acik: true, sn: sn } : { acik: false, sn: 15 } });
        });
    }

    /* PİŞİRME GEREKLİ bildirimi (moduller/firin-uyari.js, arka-plan/firin-tedarik.js); varsayılan kapalı */
    var firinGerekli = document.getElementById('firinGerekli');
    if (firinGerekli) {
        chrome.storage.local.get('jbaFirinGerekli', function (r) {
            firinGerekli.checked = !!(r && r.jbaFirinGerekli && r.jbaFirinGerekli.acik === true);
        });
        firinGerekli.addEventListener('change', function () {
            chrome.storage.local.set({ jbaFirinGerekli: { acik: firinGerekli.checked } });
        });
    }

    /* La Lorraine takibi (arka-plan/firin-tedarik.js); varsayılan açık */
    var llAcik = document.getElementById('laLorraineAcik');
    if (llAcik) {
        var llDurum = document.getElementById('laLorraineDurum');
        var llDugme = document.getElementById('laLorraineSimdi');
        var llCiz = function (v) {
            if (!llAcik.checked) { llDurum.textContent = 'Kapalı. Tedarik listesi sorulmuyor.'; return; }
            if (!v || !v.metin) { llDurum.textContent = 'Henüz kontrol yapılmadı.'; return; }
            llDurum.textContent = '';
            if (v.zaman) {
                var b = document.createElement('b');
                var d = new Date(v.zaman);
                b.textContent = 'Son kontrol ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
                llDurum.appendChild(b);
                llDurum.appendChild(document.createTextNode(' · '));
            }
            llDurum.appendChild(document.createTextNode(String(v.metin)));
        };
        var llSon = null;
        chrome.storage.local.get(['jbaLaLorraine', 'jbaLaLorraineDurum'], function (r) {
            llAcik.checked = !(r && r.jbaLaLorraine && r.jbaLaLorraine.acik === false);
            llDugme.disabled = !llAcik.checked;
            llSon = r && r.jbaLaLorraineDurum;
            llCiz(llSon);
        });
        llAcik.addEventListener('change', function () {
            chrome.storage.local.set({ jbaLaLorraine: { acik: llAcik.checked } });
            llDugme.disabled = !llAcik.checked;
            llCiz(llSon);
        });
        chrome.storage.onChanged.addListener(function (d, alan) {
            if (alan === 'local' && d.jbaLaLorraineDurum) { llSon = d.jbaLaLorraineDurum.newValue; llCiz(llSon); }
        });
        llDugme.addEventListener('click', function () {
            llDugme.disabled = true;
            llDugme.textContent = 'Kontrol ediliyor...';
            chrome.runtime.sendMessage({ type: 'JBA_LALORRAINE_SIMDI' }, function (c) {
                void chrome.runtime.lastError;
                llDugme.textContent = c && c.ok ? 'Tamam' : 'Olmadı';
                setTimeout(function () { llDugme.disabled = !llAcik.checked; llDugme.textContent = 'Şimdi Kontrol Et'; }, 3000);
            });
        });
    }

    /* Pişirme yöntemi (moduller/firin-uyari.js okuyor) */
    var YONTEM_VARSAYILAN = { ad: 'eski', hesap: 'toplam', cikar: 'kadar', esik: 1 };
    var yontemKok = document.getElementById('katYontem');
    if (yontemKok) {
        var yontemCiz = function (y) {
            Array.prototype.forEach.call(yontemKok.querySelectorAll('[data-yontem]'), function (g) {
                var alan = g.getAttribute('data-yontem');
                Array.prototype.forEach.call(g.querySelectorAll('button'), function (b) {
                    b.setAttribute('aria-checked', String(String(y[alan]) === b.getAttribute('data-deger')));
                });
            });
            var yeni = y.ad === 'yeni';
            document.getElementById('yontemYeni').hidden = !yeni;
            document.getElementById('yontemAciklama').textContent = yeni
                ? 'Öneri geride kalmasın, stok hiç bitmesin. Az satan ürün de öneri kadar pişirilir.'
                : 'Pişirme panelinin acil ve kritik satırları. Bugünkü davranış.';
            document.getElementById('yontemHesapAciklama').textContent = y.hesap === 'dilim'
                ? 'Her dilimde o dilimin önerisi kadar pişirilir. Daha çok taze ürün, daha çok atık.'
                : 'Bugün o saate kadarki toplam öneri tutturulur; önden fazla pişirilen sonraki dilimi karşılar. Puan gün toplamına bakıyor.';
            var ozet = document.getElementById('yontemOzet');
            if (ozet) ozet.textContent = yeni ? 'Yeni · ' + (y.hesap === 'dilim' ? 'her dilim' : 'gün toplamı') : 'Eski yöntem';
        };
        chrome.storage.local.get('jbaFirinYontem', function (r) {
            var y = Object.assign({}, YONTEM_VARSAYILAN, (r && r.jbaFirinYontem) || {});
            yontemCiz(y);
            yontemKok.addEventListener('click', function (e) {
                var b = e.target.closest('[data-yontem] button');
                if (!b) return;
                var alan = b.closest('[data-yontem]').getAttribute('data-yontem');
                var d = b.getAttribute('data-deger');
                y[alan] = alan === 'esik' ? Number(d) : d;
                yontemCiz(y);
                chrome.storage.local.set({ jbaFirinYontem: y });
            });
        });
    }

    /* Kopyalayınca aramaya geç (moduller/toplu-kopyalama.js okuyor; varsayılan kapalı) */
    var aramayaGec = document.getElementById('aramayaGec');
    if (aramayaGec) {
        chrome.storage.local.get('getirAutoRedirect', function (r) {
            var d = r && r.getirAutoRedirect;
            aramayaGec.value = d === true || d === 'true' ? '1' : '0';
        });
        var aramaOzetYaz = function () {
            var oz = document.getElementById('aramaOzet');
            if (oz) oz.textContent = aramayaGec.value === '1' ? 'Aramaya geçiş açık' : 'Aramaya geçiş kapalı';
        };
        aramayaGec.addEventListener('change', function () {
            chrome.storage.local.set({ getirAutoRedirect: aramayaGec.value === '1' });
            aramaOzetYaz();
        });
        chrome.storage.local.get('getirAutoRedirect', aramaOzetYaz);
    }

    /* Son kontrolün sonucu: nöbetçinin çalıştığı buradan görülüyor */
    var firinDurum = document.getElementById('firinDurum');
    function saatYaz(t) {
        var d = new Date(t);
        return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    }
    function durumCiz(v) {
        if (!firinDurum) return;
        if (!v || !v.zaman) { firinDurum.textContent = 'Henüz kontrol yapılmadı.'; return; }
        firinDurum.textContent = '';
        var b = document.createElement('b');
        b.textContent = 'Son kontrol ' + saatYaz(v.zaman);
        firinDurum.appendChild(b);
        firinDurum.appendChild(document.createTextNode(' · ' + String(v.metin || '')));
    }
    chrome.storage.local.get('jbaFirinDurum', function (r) { durumCiz(r && r.jbaFirinDurum); });
    chrome.storage.onChanged.addListener(function (d, alan) {
        if (alan === 'local' && d.jbaFirinDurum) durumCiz(d.jbaFirinDurum.newValue);
    });

    /* Günlük sayım: durum, elle ekleme, iki simülasyon */
    var gunlukDurum = document.getElementById('gunlukDurum');
    function gunlukCiz(v) {
        if (!gunlukDurum) return;
        var bugun = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Istanbul' }).format(new Date());
        var ozet = document.getElementById('gunlukOzet');
        if (!v || v.gun !== bugun) {
            gunlukDurum.textContent = 'Bugün henüz eklenmedi.';
            if (ozet) ozet.textContent = 'Bugün henüz eklenmedi';
            return;
        }
        if (ozet) ozet.textContent = (v.durum === 'eklendi' ? 'Bugün eklendi · ' + (v.adet || 0) + ' ürün' : String(v.metin || '')) + ' · ' + saatYaz(v.zaman);
        gunlukDurum.textContent = '';
        var b = document.createElement('b');
        b.textContent = saatYaz(v.zaman);
        gunlukDurum.appendChild(b);
        gunlukDurum.appendChild(document.createTextNode(' · ' + String(v.metin || '')));
    }
    chrome.storage.local.get('jbaGunlukSayim', function (r) { gunlukCiz(r && r.jbaGunlukSayim); });
    chrome.storage.onChanged.addListener(function (d, alan) {
        if (alan === 'local' && d.jbaGunlukSayim) gunlukCiz(d.jbaGunlukSayim.newValue);
    });
    function gunlukDugme(id, mesaj, mesgulYazi, durumEl) {
        var b = document.getElementById(id);
        if (!b) return;
        var ilk = b.textContent;
        b.addEventListener('click', function () {
            b.disabled = true;
            b.textContent = mesgulYazi;
            chrome.runtime.sendMessage(mesaj, function (c) {
                void chrome.runtime.lastError;
                b.textContent = c && c.ok ? 'Tamam' : 'Olmadı';
                var hedef = durumEl || gunlukDurum;
                if (hedef && c && c.metin) hedef.textContent = c.metin;
                setTimeout(function () { b.disabled = false; b.textContent = ilk; }, 3000);
            });
        });
    }
    /* Aç/kapa: her biri ayrı; varsayılan hepsi açık */
    var GUNLUK_SECENEK = { gunlukAyarEkle: 'ekle', gunlukAyarSabah: 'sabah', gunlukAyarGece: 'gece' };
    chrome.storage.local.get('jbaGunlukAyar', function (r) {
        var a = (r && r.jbaGunlukAyar) || {};
        Object.keys(GUNLUK_SECENEK).forEach(function (id) {
            var k = document.getElementById(id);
            if (!k) return;
            k.checked = a[GUNLUK_SECENEK[id]] !== false;
            k.addEventListener('change', function () {
                chrome.storage.local.get('jbaGunlukAyar', function (r2) {
                    var y = Object.assign({}, (r2 && r2.jbaGunlukAyar) || {});
                    y[GUNLUK_SECENEK[id]] = k.checked;
                    chrome.storage.local.set({ jbaGunlukAyar: y });
                });
            });
        });
    });
    gunlukDugme('gunlukEkle', { type: 'JBA_GUNLUK_EKLE' }, 'Okunuyor...');

    /* Fırın sesi (arka-plan/firin-ses.js okuyor; varsayılanlar orada da aynı) */
    var SES_VARSAYILAN = {
        duzey: 100, satis: 'her', ses: 'zil', tekrar: 1,
        kritik: true, kritikSes: 'siren', kritikSure: 5, kritikTekrar: 2, kritikAralik: 30, kritikEnCok: 0,
        cikis: true, cikisSes: 'alarm', cikisSure: 5, cikisTekrar: 2, hatirlat: 50
    };
    /* Ayar alanı -> öğe kimliği; sayılar sayı olarak saklanır */
    var SES_ALAN = {
        satis: 'sesSatis', ses: 'sesTur', tekrar: 'sesTekrar',
        kritikSes: 'sesKritikTur', kritikSure: 'sesKritikSure', kritikTekrar: 'sesKritikTekrar',
        kritikAralik: 'sesKritikAralik', kritikEnCok: 'sesKritikEnCok',
        cikisSes: 'sesCikisTur', cikisSure: 'sesCikisSure', cikisTekrar: 'sesCikisTekrar', hatirlat: 'sesHatirlat'
    };
    var SAYI_ALAN = ['tekrar', 'kritikSure', 'kritikTekrar', 'kritikAralik', 'kritikEnCok', 'cikisSure', 'cikisTekrar', 'hatirlat'];
    var sesEl = function (id) { return document.getElementById(id); };
    var sesler = (globalThis.JBASes && globalThis.JBASes.SESLER) || [];
    var sesGruplari = (globalThis.JBASes && globalThis.JBASes.GRUPLAR) || [];
    ['sesTur', 'sesKritikTur', 'sesCikisTur'].forEach(function (id) {
        var s = sesEl(id);
        if (!s) return;
        sesGruplari.forEach(function (g) {
            var og = document.createElement('optgroup');
            og.label = g.baslik;
            sesler.forEach(function (x) {
                if (x.grup !== g.ad) return;
                var o = document.createElement('option');
                o.value = x.ad;
                o.textContent = x.baslik;
                og.appendChild(o);
            });
            s.appendChild(og);
        });
    });
    function sesGrup(ad, acik) {
        Array.prototype.forEach.call(document.querySelectorAll('[data-grup="' + ad + '"]'), function (e) { e.hidden = !acik; });
    }
    function sesFormu(a) {
        Object.keys(SES_ALAN).forEach(function (k) { sesEl(SES_ALAN[k]).value = String(a[k]); });
        sesEl('sesDuzey').value = String(a.duzey);
        sesEl('sesDuzeyYazi').textContent = '%' + a.duzey;
        sesEl('sesKritik').checked = a.kritik;
        sesEl('sesCikis').checked = a.cikis;
        sesGrup('satis', a.satis === 'her');
        sesGrup('kritik', a.kritik);
        sesGrup('cikis', a.cikis);
        var parca = [a.satis === 'her' ? 'Her satışta' : 'Satış sessiz', a.kritik ? 'kritik alarm açık' : 'kritik alarm kapalı', '%' + a.duzey];
        var ozet = sesEl('sesOzet');
        if (ozet) ozet.textContent = parca.join(' · ');
    }
    function sesOku() {
        var y = {
            duzey: parseInt(sesEl('sesDuzey').value, 10) || 100,
            kritik: sesEl('sesKritik').checked,
            cikis: sesEl('sesCikis').checked
        };
        Object.keys(SES_ALAN).forEach(function (k) {
            var v = sesEl(SES_ALAN[k]).value;
            y[k] = SAYI_ALAN.indexOf(k) !== -1 ? parseInt(v, 10) || 0 : v;
        });
        return y;
    }
    if (sesEl('sesSatis')) {
        chrome.storage.local.get('jbaFirinSes', function (r) {
            var k = (r && r.jbaFirinSes) || {};
            var a = Object.assign({}, SES_VARSAYILAN, k);
            // 0.49.0'daki "yalnız kritik stokta" satış seçeneği
            if (a.satis === 'kritik') { a.satis = 'kapali'; a.kritik = true; }
            sesFormu(a);
            var kaydet = function () {
                var y = sesOku();
                sesFormu(y);
                chrome.storage.local.set({ jbaFirinSes: y });
            };
            Object.keys(SES_ALAN).map(function (x) { return SES_ALAN[x]; }).concat(['sesKritik', 'sesCikis', 'sesDuzey']).forEach(function (id) {
                sesEl(id).addEventListener('change', kaydet);
            });
            sesEl('sesDuzey').addEventListener('input', function () {
                sesEl('sesDuzeyYazi').textContent = '%' + sesEl('sesDuzey').value;
            });
        });
        /* Dinle: seçili ayarla, bu pencerede */
        Array.prototype.forEach.call(document.querySelectorAll('[data-dinle]'), function (b) {
            b.addEventListener('click', function () {
                var a = sesOku();
                var tur = b.getAttribute('data-dinle');
                var c = tur === 'kritik' ? { ses: a.kritikSes, tekrar: a.kritikTekrar, sure: a.kritikSure }
                    : tur === 'cikis' ? { ses: a.cikisSes, tekrar: a.cikisTekrar, sure: a.cikisSure }
                    : { ses: a.ses, tekrar: a.tekrar, sure: 0 };
                try { globalThis.JBASes.dur(); globalThis.JBASes.cal(c.ses, { tekrar: c.tekrar, sure: c.sure, duzey: a.duzey }); } catch (e) { /* ses yok */ }
            });
        });
        var sesDurum = sesEl('sesDurum');
        var sesSonCiz = function (v) {
            if (!sesDurum) return;
            if (!v || !v.zaman) { sesDurum.textContent = 'Henüz çalmadı.'; return; }
            sesDurum.textContent = '';
            var b = document.createElement('b');
            b.textContent = 'Son çalma ' + saatYaz(v.zaman);
            sesDurum.appendChild(b);
            sesDurum.appendChild(document.createTextNode(' · ' + String(v.metin || '')));
        };
        /* Çalan kritik alarm ve Sustur */
        var alarmCiz = function (v) {
            var adlar = (v && Array.isArray(v.adlar)) ? v.adlar : [];
            sesEl('sesCalan').hidden = !adlar.length;
            sesEl('sesCalanYazi').textContent = adlar.length ? 'Alarm çalıyor: ' + adlar.slice(0, 3).join(', ') + (adlar.length > 3 ? ' +' + (adlar.length - 3) : '') : '';
        };
        chrome.storage.local.get(['jbaFirinSesSon', 'jbaFirinAlarm'], function (r) {
            sesSonCiz(r && r.jbaFirinSesSon);
            alarmCiz(r && r.jbaFirinAlarm);
        });
        chrome.storage.onChanged.addListener(function (d, alan) {
            if (alan !== 'local') return;
            if (d.jbaFirinSesSon) sesSonCiz(d.jbaFirinSesSon.newValue);
            if (d.jbaFirinAlarm) alarmCiz(d.jbaFirinAlarm.newValue);
        });
        sesEl('sesSustur').addEventListener('click', function () {
            chrome.runtime.sendMessage({ type: 'JBA_FIRIN_SES_SUSTUR' }, function () { void chrome.runtime.lastError; });
        });
    }

    /* Kurye uyarısı (arka-plan/kurye-nobet.js okuyor; varsayılanlar orada da aynı) */
    var KURYE_VARSAYILAN = { acik: true, sn: 15, eksik: true, mola: true, esik: { mesgul: 60 }, ses: 'kampana', sesAcik: true, sesAralik: 2 };
    var esikKutulari = Array.prototype.slice.call(document.querySelectorAll('[data-esik]'));
    var kEl = function (id) { return document.getElementById(id); };
    if (kEl('kuryeSn')) {
        var kSes = kEl('kuryeSes');
        sesGruplari.forEach(function (g) {
            var og = document.createElement('optgroup');
            og.label = g.baslik;
            sesler.forEach(function (x) {
                if (x.grup !== g.ad) return;
                var o = document.createElement('option');
                o.value = x.ad;
                o.textContent = x.baslik;
                og.appendChild(o);
            });
            kSes.appendChild(og);
        });
        var kGoster = function (ad, acik) {
            Array.prototype.forEach.call(document.querySelectorAll('[data-kurye="' + ad + '"]'), function (e) { e.hidden = !acik; });
        };
        var kFormu = function (a) {
            kEl('kuryeAcik').checked = a.acik;
            kEl('kuryeEksik').checked = a.eksik;
            kEl('kuryeMola').checked = a.mola;
            kEl('kuryeSesAcik').checked = a.sesAcik;
            kEl('kuryeSn').value = String(a.sn);
            esikKutulari.forEach(function (k) {
                if (document.activeElement === k) return; // yazarken kutu değişmesin
                var v = a.esik && a.esik[k.getAttribute('data-esik')];
                k.value = v ? String(v) : '';
            });
            kEl('kuryeSes').value = a.ses;
            kEl('kuryeSesAralik').value = String(a.sesAralik);
            kGoster('acik', a.acik);
            kGoster('mola', a.acik && a.mola);
            kGoster('ses', a.sesAcik);
            var oz = kEl('kuryeOzet');
            if (oz) oz.textContent = a.acik ? (a.sn === 60 ? 'Dakikada bir' : a.sn + " sn'de bir") + (a.sesAcik ? '' : ' · sessiz') : 'Kapalı';
        };
        var kOku = function () {
            return {
                acik: kEl('kuryeAcik').checked,
                sn: parseInt(kEl('kuryeSn').value, 10) || 15,
                eksik: kEl('kuryeEksik').checked,
                mola: kEl('kuryeMola').checked,
                esik: esikKutulari.reduce(function (e, k) {
                    var n = Math.round(Number(k.value));
                    if (k.value !== '' && n >= 1 && n <= 600) e[k.getAttribute('data-esik')] = n;
                    return e;
                }, {}),
                ses: kEl('kuryeSes').value || 'kampana',
                sesAcik: kEl('kuryeSesAcik').checked,
                sesAralik: parseInt(kEl('kuryeSesAralik').value, 10) || 2
            };
        };
        chrome.storage.local.get('jbaKurye', function (r) {
            var kayit = Object.assign({}, KURYE_VARSAYILAN, (r && r.jbaKurye) || {});
            // 0.57.0'daki tek meşgul eşiği
            if (!(r && r.jbaKurye && r.jbaKurye.esik) && r && r.jbaKurye && r.jbaKurye.molaDk) kayit.esik = { mesgul: Number(r.jbaKurye.molaDk) || 60 };
            kFormu(kayit);
            var kKaydet = function () {
                var y = kOku();
                kFormu(y);
                chrome.storage.local.set({ jbaKurye: y });
            };
            ['kuryeAcik', 'kuryeEksik', 'kuryeMola', 'kuryeSesAcik', 'kuryeSn', 'kuryeSes', 'kuryeSesAralik'].forEach(function (id) {
                kEl(id).addEventListener('change', kKaydet);
            });
            var esikZaman = null;
            esikKutulari.forEach(function (k) {
                k.addEventListener('input', function () {
                    if (k.value.length > 3) k.value = k.value.slice(0, 3);
                    clearTimeout(esikZaman);
                    esikZaman = setTimeout(kKaydet, 500);
                });
                k.addEventListener('blur', function () {
                    clearTimeout(esikZaman);
                    var n = Math.round(Number(k.value));
                    if (k.value !== '' && !(n >= 1 && n <= 600)) k.value = '';
                    kKaydet();
                    var v = kOku().esik[k.getAttribute('data-esik')];
                    k.value = v ? String(v) : '';
                });
            });
        });
        kEl('kuryeDinle').addEventListener('click', function () {
            var duzey = parseInt((sesEl('sesDuzey') || {}).value, 10) || 100;
            try { globalThis.JBASes.dur(); globalThis.JBASes.cal(kEl('kuryeSes').value, { tekrar: 2, sure: 0, duzey: duzey }); } catch (e) { /* ses yok */ }
        });
        var kDurum = kEl('kuryeDurum');
        var kDurumCiz = function (v) {
            if (!v || !v.zaman) { kDurum.textContent = 'Henüz kontrol yapılmadı.'; return; }
            kDurum.textContent = '';
            var b = document.createElement('b');
            b.textContent = saatYaz(v.zaman);
            kDurum.appendChild(b);
            var metin = v.hata ? String(v.hata)
                : 'Planlanan ' + v.planlanan + ' · Aktif ' + v.aktif + ' · Meşgul ' + ((v.sayi && v.sayi.mesgul) || 0) +
                    (v.sayi && v.sayi.iade ? ' · İadede ' + v.sayi.iade : '');
            kDurum.appendChild(document.createTextNode(' · ' + metin));
        };
        chrome.storage.local.get('jbaKuryeDurum', function (r) { kDurumCiz(r && r.jbaKuryeDurum); });
        chrome.storage.onChanged.addListener(function (d, alan) {
            if (alan === 'local' && d.jbaKuryeDurum) kDurumCiz(d.jbaKuryeDurum.newValue);
        });
        var kDugme = function (id, tip, mesgul, ilk) {
            var b = kEl(id);
            b.addEventListener('click', function () {
                b.disabled = true;
                b.textContent = mesgul;
                chrome.runtime.sendMessage({ type: tip }, function (c) {
                    void chrome.runtime.lastError;
                    b.textContent = c && c.ok ? 'Tamam' : 'Olmadı';
                    if (c && !c.ok && c.metin) kDurum.textContent = c.metin;
                    setTimeout(function () { b.disabled = false; b.textContent = ilk; }, 3000);
                });
            });
        };
        /* Ertelemeler: durum satırı ve sıfırlama */
        var kErt = kEl('kuryeErteleDurum');
        var kErtDugme = kEl('kuryeErteleSifirla');
        var kErtKayit = null;
        var kErtCiz = function () {
            var e = kErtKayit || {};
            var simdi = Date.now();
            var parca = [];
            if (Number(e.eksik) > simdi) parca.push('Kurye eksiği ' + Math.max(1, Math.ceil((e.eksik - simdi) / 60000)) + ' dk daha ertelendi');
            var kisi = {};
            Object.keys(e.mola || {}).forEach(function (k) { if (Number(e.mola[k]) > simdi) kisi[k.split(':')[0]] = 1; });
            var n = Object.keys(kisi).length;
            if (n) parca.push(n + ' kurye kartı ertelendi');
            kErt.textContent = parca.length ? parca.join(' · ') : 'Ertelenen uyarı yok.';
            kErtDugme.disabled = !parca.length;
        };
        chrome.storage.local.get('jbaKuryeErtele', function (r) { kErtKayit = r && r.jbaKuryeErtele; kErtCiz(); });
        chrome.storage.onChanged.addListener(function (d, alan) {
            if (alan === 'local' && d.jbaKuryeErtele) { kErtKayit = d.jbaKuryeErtele.newValue; kErtCiz(); }
        });
        setInterval(kErtCiz, 15000);
        kErtDugme.addEventListener('click', function () {
            kErtDugme.disabled = true;
            chrome.runtime.sendMessage({ type: 'JBA_KURYE_ERTELE_SIFIRLA' }, function () { void chrome.runtime.lastError; });
        });
        kDugme('kuryeSimdi', 'JBA_KURYE_SIMDI', 'Kontrol ediliyor...', 'Şimdi Kontrol Et');
        kDugme('kuryeSim', 'JBA_KURYE_SIM', 'Hazırlanıyor...', 'Simülasyonu Göster');
    }

    /* Sol menü: bölüm seçimi, son seçilen hatırlanır; yukarı/aşağı okla gezilir */
    var menuOgeleri = Array.prototype.slice.call(document.querySelectorAll('.menu__oge'));
    function bolumSec(ad, odakla) {
        menuOgeleri.forEach(function (b) {
            var sec = b.getAttribute('data-bolum') === ad;
            b.setAttribute('aria-selected', String(sec));
            b.tabIndex = sec ? 0 : -1;
            if (sec && odakla) b.focus();
        });
        Array.prototype.forEach.call(document.querySelectorAll('.bolum'), function (bl) {
            bl.hidden = bl.getAttribute('data-bolum') !== ad;
        });
        var ic = document.querySelector('.icerik');
        if (ic) ic.scrollTop = 0;
        try { localStorage.setItem('jbaKapiBolum', ad); } catch (e) { /* sessiz */ }
    }
    menuOgeleri.forEach(function (b, i) {
        b.addEventListener('click', function () { bolumSec(b.getAttribute('data-bolum')); });
        b.addEventListener('keydown', function (e) {
            if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
            e.preventDefault();
            var j = (i + (e.key === 'ArrowDown' ? 1 : menuOgeleri.length - 1)) % menuOgeleri.length;
            bolumSec(menuOgeleri[j].getAttribute('data-bolum'), true);
        });
    });
    var ilkBolum = 'durum';
    try { ilkBolum = localStorage.getItem('jbaKapiBolum') || 'durum'; } catch (e) { /* sessiz */ }
    if (!document.querySelector('.menu__oge[data-bolum="' + ilkBolum + '"]')) ilkBolum = 'durum';
    bolumSec(ilkBolum);

    /* Açılır kapanır bölümler: son durum hatırlanır */
    Array.prototype.forEach.call(document.querySelectorAll('.kat__bas'), function (b) {
        var govde = document.getElementById(b.getAttribute('aria-controls'));
        var anahtar = 'jbaKapiKat_' + b.getAttribute('aria-controls');
        var ac = function (acik) {
            b.setAttribute('aria-expanded', String(acik));
            govde.hidden = !acik;
        };
        try { ac(localStorage.getItem(anahtar) === '1'); } catch (e) { ac(false); }
        b.addEventListener('click', function () {
            var acik = b.getAttribute('aria-expanded') !== 'true';
            ac(acik);
            try { localStorage.setItem(anahtar, acik ? '1' : '0'); } catch (e) { /* sessiz */ }
        });
    });
    gunlukDugme('gunlukSimSabah', { type: 'JBA_GUNLUK_SIM', tur: 'sabah' }, 'Gösteriliyor...');
    gunlukDugme('gunlukSimGece', { type: 'JBA_GUNLUK_SIM', tur: 'gece' }, 'Gösteriliyor...');

    /* Simülasyon: tek sefer, gerçek ürünlerden rastgele eksik, kart 20 sn */
    var firinSim = document.getElementById('firinSim');
    if (firinSim) {
        firinSim.addEventListener('click', function () {
            firinSim.disabled = true;
            firinSim.textContent = 'Hazırlanıyor...';
            chrome.runtime.sendMessage({ type: 'JBA_FIRIN_SIM' }, function (c) {
                void chrome.runtime.lastError;
                firinSim.textContent = c && c.ok ? 'Panelde Gösterildi' : 'Gösterilemedi';
                if (firinDurum && c && !c.ok && c.metin) firinDurum.textContent = c.metin;
                setTimeout(function () {
                    firinSim.disabled = false;
                    firinSim.textContent = 'Simülasyonu Göster';
                }, 3000);
            });
        });
    }
})();

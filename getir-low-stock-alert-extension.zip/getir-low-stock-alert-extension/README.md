# Getir Düşük Stok Uyarısı

Stok hareketleri API'sine göre eşiğin altına düşen ürünlerde sesli/görsel bildirim ve barkod sitesinde "Stoğu düşük ürünler" listesi.

## Kurulum

1. Chrome'da `chrome://extensions` → Geliştirici modu → "Paketlenmemiş öğe yükle" → bu klasörü seçin.
2. **İkon:** `getir-stock-sync-extension` klasöründeki `icon128.png` dosyasını bu klasöre kopyalayın (veya kendi ikonunuzu `icon128.png` adıyla ekleyin).
3. **Ses (isteğe bağlı):** Bildirim sesi için kısa bir MP3 dosyasını `notification.mp3` adıyla bu klasöre ekleyin. Yoksa sadece görsel bildirim çalışır.

## Kullanım

- Admin, kullanıcıya "Düşük Stok Uyarısı" premium özelliğini açar.
- Kullanıcı barkod sitesinde **Stoğu düşük ürünler** sayfasına gider; özelliği açar, varsayılan eşiği ve isteğe bağlı ürün bazlı eşikleri ayarlar.
- **Getir franchise** sayfası (`https://franchise.getir.com/stock/movements` veya stok sayfası) açıkken eklenti token'ı yakalar ve yaklaşık her 1 dakikada stok hareketleri API'sini çağırır (en fazla 3 sayfa, 300 hareket).
- Eşiğin altına düşen ürünler listelenir; her yeni düşüşte veya sayı değişiminde bildirim (ve isteğe bağlı ses) verilir.
- "Tamam, kontrol ettim" ile ürün listeden çıkar; tekrar eşiğin altına düşerse yeniden uyarı verilir.

## Gereksinimler

- Barkod sitesinde giriş yapılmış olmalı; premium özellik kullanıcıya açık olmalı.
- Liste ve bildirimler için Getir franchise sekmesi açık olmalı (token alınması için).

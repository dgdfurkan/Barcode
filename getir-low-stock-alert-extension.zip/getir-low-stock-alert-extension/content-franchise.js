// Franchise sayfasında çalışır: token yakala, movements API'yi sayfa context'inde çağır.
(function () {
  if (window.location.hostname !== 'franchise.getir.com') return;

  let token = null;
  const MOVEMENTS_BASE = 'https://franchise-api-gateway.getirapi.com/stocks/stock-movements';
  const MAX_PAGES = 3;
  const PAGE_DELAY_MS = 2000;

  function captureTokenFromRequest(url, headers) {
    if (!url || !url.includes('getirapi.com')) return;
    const auth = headers && (headers.Authorization || headers.authorization);
    if (auth && auth.startsWith('Bearer ')) {
      token = auth;
      try {
        chrome.runtime.sendMessage({ type: 'TOKEN_FROM_FRANCHISE', token: auth }).catch(() => {});
      } catch (_) {}
    }
  }

  const origFetch = window.fetch;
  window.fetch = function (url, opts) {
    const u = typeof url === 'string' ? url : (url && url.url);
    const headers = (opts && opts.headers) || (url && url.headers);
    if (headers && headers.get) {
      const auth = headers.get('Authorization') || headers.get('authorization');
      if (auth) captureTokenFromRequest(u, { Authorization: auth });
    } else if (headers && (headers.Authorization || headers.authorization)) {
      captureTokenFromRequest(u, headers);
    }
    return origFetch.apply(this, arguments);
  };

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type !== 'FETCH_MOVEMENTS_FOR_POLL') return;
    (async function () {
      if (!token) return { error: 'Token yok' };
      const allData = [];
      let offset = 0;
      let hasNext = true;
      let pages = 0;
      while (hasNext && pages < MAX_PAGES) {
        const url = MOVEMENTS_BASE + '?limit=100&offset=' + offset;
        const res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': token
          },
          body: JSON.stringify({})
        });
        if (!res.ok) return { error: 'API ' + res.status };
        const json = await res.json();
        const list = json.data || [];
        allData.push(...list);
        hasNext = json.hasNext === true;
        offset += 100;
        pages++;
        if (hasNext && pages < MAX_PAGES) await new Promise(r => setTimeout(r, PAGE_DELAY_MS));
      }
      return { data: allData };
    })().then(sendResponse);
    return true;
  });
})();

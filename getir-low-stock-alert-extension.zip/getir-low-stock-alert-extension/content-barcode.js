// Barkod sitesinde çalışır: sayfadan LOW_STOCK_INIT alır, background'a iletir; listeyi sayfaya postMessage ile gönderir; MARK_DONE iletir.
(function () {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'LOW_STOCK_LIST_UPDATE') {
      window.postMessage({ type: 'LOW_STOCK_LIST_UPDATE', list: msg.list || [], username: msg.username }, '*');
    }
  });

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data) return;
    if (e.data.type === 'LOW_STOCK_INIT' && e.data.payload) {
      chrome.runtime.sendMessage({ type: 'LOW_STOCK_INIT', payload: e.data.payload }, (response) => {
        if (response && response.username !== undefined) {
          window.postMessage({ type: 'LOW_STOCK_LIST_UPDATE', list: response.list || [], username: response.username }, '*');
        }
      });
    }
    if (e.data.type === 'LOW_STOCK_MARK_DONE' && e.data.productId) {
      const username = (window.authUtils && window.authUtils.checkAuth && window.authUtils.checkAuth())?.username;
      if (username) {
        chrome.runtime.sendMessage({ type: 'MARK_DONE', username, productId: e.data.productId }, () => {});
      }
    }
  });
})();

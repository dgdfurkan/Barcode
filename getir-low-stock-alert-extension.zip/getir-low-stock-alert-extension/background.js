// Getir Düşük Stok Uyarısı - Background
// Token franchise content script'ten alınır; stock-movements API franchise tab'ında fetch edilir; listeyi saklar ve bildirir.

const MOVEMENTS_BASE = 'https://franchise-api-gateway.getirapi.com/stocks/stock-movements';
const POLL_INTERVAL_MINUTES = 1;
const MAX_PAGES_PER_POLL = 3;
const PAGE_DELAY_MS = 2000;

function getThresholdForProduct(productId, barcode, defaultThreshold, overrides) {
  if (overrides && overrides[productId] !== undefined) return overrides[productId];
  if (barcode && overrides && overrides[barcode] !== undefined) return overrides[barcode];
  return defaultThreshold;
}

function processMovementsToLowStockList(data, defaultThreshold, overrides) {
  const byProduct = new Map();
  for (const row of data) {
    const product = row.product;
    const productId = product && (product.id || product._id);
    const productStock = row.productStock;
    if (!productId || !productStock) continue;
    if (byProduct.has(productId)) continue;
    const available = productStock.available;
    if (typeof available !== 'number') continue;
    const name = (product.name && (product.name.tr || product.name.en)) || '';
    let barcode = '';
    try {
      const pi = product.packagingInfo && product.packagingInfo['1'];
      if (pi && pi.barcodes && pi.barcodes[0]) barcode = String(pi.barcodes[0]);
    } catch (_) {}
    const threshold = getThresholdForProduct(productId, barcode, defaultThreshold, overrides || {});
    if (available < threshold) {
      byProduct.set(productId, { productId, name, barcode, available, threshold });
    }
  }
  return Array.from(byProduct.values());
}

async function getStoredList(username) {
  const key = 'lowStockList_' + username;
  const out = await chrome.storage.local.get(key);
  return out[key] || [];
}

async function setStoredList(username, list) {
  const key = 'lowStockList_' + username;
  await chrome.storage.local.set({ [key]: list });
}

async function getMarkedDoneSet(username) {
  const key = 'lowStockMarkedDone_' + username;
  const out = await chrome.storage.local.get(key);
  return out[key] || {};
}

async function setMarkedDone(username, productId, done) {
  const key = 'lowStockMarkedDone_' + username;
  const obj = await getMarkedDoneSet(username);
  if (done) obj[productId] = true;
  else delete obj[productId];
  await chrome.storage.local.set({ [key]: obj });
}

const userConfigByUsername = {};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'LOW_STOCK_INIT' && msg.payload) {
    const p = msg.payload;
    if (p.username) {
      userConfigByUsername[p.username] = {
        threshold: p.threshold,
        overrides: p.overrides || {},
        soundEnabled: p.soundEnabled !== false,
        featureEnabled: p.featureEnabled === true
      };
      getStoredList(p.username).then(list => {
        sendResponse({ ok: true, list, username: p.username });
      });
    } else sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'GET_LOW_STOCK_LIST' && msg.username) {
    getStoredList(msg.username).then(sendResponse);
    return true;
  }
  if (msg.type === 'MARK_DONE' && msg.username && msg.productId) {
    (async () => {
      const list = await getStoredList(msg.username);
      const next = list.filter(item => item.productId !== msg.productId);
      await setStoredList(msg.username, next);
      await setMarkedDone(msg.username, msg.productId, true);
      return { ok: true };
    })().then(sendResponse);
    return true;
  }
  if (msg.type === 'MOVEMENTS_RESULT') {
    handleMovementsResult(msg).then(sendResponse).catch(e => sendResponse({ error: e.message }));
    return true;
  }
});

async function handleMovementsResult(msg) {
  const username = msg.username;
  const config = userConfigByUsername[username];
  if (!config || !config.featureEnabled) return { ok: true };
  const data = msg.data || [];
  const list = processMovementsToLowStockList(data, config.threshold, config.overrides);
  const markedDone = await getMarkedDoneSet(username);
  const filtered = list.filter(item => !markedDone[item.productId]);
  const prev = await getStoredList(username);
  await setStoredList(username, filtered);

  const prevById = new Map(prev.map(p => [p.productId, p]));
  for (const item of filtered) {
    const prevItem = prevById.get(item.productId);
    const isNew = !prevItem;
    const countDropped = prevItem && prevItem.available !== item.available;
    if (isNew || countDropped) {
      try {
        await chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icon128.png',
          title: 'Düşük stok uyarısı',
          message: (item.name || item.productId) + ': kalan ' + item.available + ' (eşik: ' + item.threshold + ')'
        });
      } catch (_) {}
      if (config.soundEnabled) {
        try {
          const a = new Audio(chrome.runtime.getURL('notification.mp3'));
          a.volume = 0.5;
          a.play().catch(() => {});
        } catch (_) {}
      }
    }
  }

  chrome.tabs.query({ url: ['http://localhost/*', 'http://127.0.0.1/*', 'https://dgdfurkan.github.io/*'] }, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, { type: 'LOW_STOCK_LIST_UPDATE', username, list: filtered }).catch(() => {});
    });
  });
  return { ok: true };
}

chrome.alarms.create('pollLowStock', { periodInMinutes: POLL_INTERVAL_MINUTES });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== 'pollLowStock') return;
  chrome.tabs.query({ url: 'https://franchise.getir.com/*' }, (tabs) => {
    if (!tabs.length) return;
    chrome.tabs.sendMessage(tabs[0].id, { type: 'FETCH_MOVEMENTS_FOR_POLL' }, (res) => {
      if (!res || res.error || !res.data) return;
      const data = res.data;
      Object.keys(userConfigByUsername).forEach((username) => {
        handleMovementsResult({ username, data }).catch(() => {});
      });
    });
  });
});
